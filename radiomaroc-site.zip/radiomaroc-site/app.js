(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }

  var I = window.RM_I18N || { loading: 'جاري التحميل…', live: 'مباشر', paused: 'متوقف مؤقتاً', unavail: 'البث غير متوفر حالياً',
    fail: 'تعذّر تشغيل هذا البث. جرّب محطة أخرى أو أعد المحاولة لاحقاً.', playing: 'قيد التشغيل', listen: 'استمع',
    fav_add: 'أضيفت إلى المفضلة', fav_del: 'أزيلت من المفضلة', copied: 'تم نسخ الرابط', brand: 'راديو المغرب' };
  var BOT = /bot|crawl|spider|slurp|bing|google|yandex|baidu|duckduck|facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegram|lighthouse|pagespeed|headless|preview/i;
  var isBot = BOT.test(navigator.userAgent) || navigator.webdriver;

  var toastTimer;
  function toast(msg) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2600);
  }

  /* ================= persistent player ================= */
  var audio = new Audio();
  audio.preload = 'none';
  var hls = null, currentId = null, hlsPromise = null, byId = {};
  var lastTrack = '', npTimer = null, recent = [];
  var NP = window.RM_NP || {};
  var ICON_PLAY = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
  var ICON_PAUSE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>';
  function P() { return { bar: $('#playerBar'), name: $('#pName'), status: $('#pStatus'), dot: $('#pDot'), logo: $('#pLogo'), play: $('#playBtn') }; }

  function readStations(root) {
    try {
      var el = $('#stations-data', root);
      if (!el) return;
      JSON.parse(el.textContent).forEach(function (s) { byId[s.id] = s; });
    } catch (e) {}
  }

  /* ---- now playing: track title from HLS/ID3 cues or an optional JSON endpoint ---- */
  function getPath(o, path) {
    try { return String(path || '').split('.').reduce(function (a, k) { return a == null ? a : a[/^\d+$/.test(k) ? +k : k]; }, o); } catch (e) { return null; }
  }
  function renderTrack() {
    var el = $('#pTrack'), s = byId[currentId];
    if (el) {
      if (lastTrack) { el.textContent = lastTrack; el.classList.add('is-track'); }
      else { el.textContent = s && s.sub ? s.sub : ''; el.classList.remove('is-track'); }
    }
    $$('.station').forEach(function (c) {
      var n = $('.np', c);
      if (!n) return;
      var on = currentId === +c.getAttribute('data-id') && !!lastTrack;
      n.hidden = !on;
      if (on) n.textContent = '♪ ' + lastTrack;
    });
    if ('mediaSession' in navigator && s) {
      try {
        var md = { title: lastTrack || s.name, artist: lastTrack ? s.name : (I.brand || 'راديو المغرب') };
        if (s.logo) md.artwork = [{ src: s.logo, sizes: '192x192' }];
        navigator.mediaSession.metadata = new MediaMetadata(md);
      } catch (e) {}
    }
  }
  function setTrack(t) {
    t = (t || '').replace(/\s+/g, ' ').trim();
    if (!t || t === lastTrack) return;
    var s = byId[currentId];
    if (s && t.toLowerCase() === (s.name || '').toLowerCase()) return;
    lastTrack = t.slice(0, 140);
    renderTrack();
  }
  function cueInfo(cue) {
    var v = cue && cue.value, o = {};
    if (v && typeof v === 'object') {
      if (v.key === 'TIT2' || v.key === 'TT2') o.t = String(v.data || '');
      else if (v.key === 'TPE1' || v.key === 'TP1') o.a = String(v.data || '');
      else if (v.key === 'TXXX' && v.data && /title|streamtitle/i.test(String(v.info || ''))) o.t = String(v.data);
    }
    if (!o.t && !o.a && cue && cue.text && !/^\s*$/.test(cue.text)) o.t = cue.text;
    return o;
  }
  function hookTrack(tr) {
    if (!tr || tr.__rm) return;
    tr.__rm = 1;
    if (tr.kind !== 'metadata' && tr.kind !== 'subtitles' && tr.kind !== 'captions') return;
    tr.mode = 'hidden';
    tr.addEventListener('cuechange', function () {
      var t = '', a = '', cues = tr.activeCues || [];
      for (var i = 0; i < cues.length; i++) { var o = cueInfo(cues[i]); if (o.t) t = o.t; if (o.a) a = o.a; }
      if (t || a) setTrack(a && t ? a + ' – ' + t : (t || a));
    });
  }
  try {
    audio.textTracks.addEventListener('addtrack', function (e) { hookTrack(e.track); });
  } catch (e) {}
  function pollNP() {
    clearInterval(npTimer);
    var id = currentId, cfg = NP && NP[id];
    if (!cfg || !cfg.url) return;
    function go() {
      if (currentId !== id || document.hidden) return;
      fetch(cfg.url, { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) {
        var v = getPath(j, cfg.path);
        if (typeof v === 'string' && v.trim()) setTrack(v);
      }).catch(function () { clearInterval(npTimer); });
    }
    go();
    npTimer = setInterval(go, Math.max(10, +cfg.every || 20) * 1000);
  }
  function pushRecent(id) {
    recent = recent.filter(function (x) { return x !== id; });
    recent.unshift(id);
    recent = recent.slice(0, 8);
    lsSet('rm_recent', JSON.stringify(recent));
    renderRecent();
  }
  function renderRecent() {
    var box = $('#recentBox'), list = $('#recentList');
    if (!box || !list) return;
    try { recent = JSON.parse(lsGet('rm_recent') || '[]'); } catch (e) { recent = []; }
    recent = recent.filter(function (id) { return byId[id]; });
    box.hidden = recent.length === 0;
    list.innerHTML = '';
    recent.forEach(function (id) {
      var s = byId[id], b = document.createElement('button');
      b.type = 'button'; b.className = 'rchip'; b.setAttribute('data-play', id);
      var ic = document.createElement('span'); ic.className = 'rl'; ic.textContent = s.init;
      if (s.logo) { var im = new Image(); im.alt = ''; im.referrerPolicy = 'no-referrer'; im.onload = function () { ic.textContent = ''; ic.appendChild(im); }; im.src = s.logo; }
      var nm = document.createElement('span'); nm.textContent = s.name;
      b.appendChild(ic); b.appendChild(nm); list.appendChild(b);
    });
  }

  function loadHls() {
    if (window.Hls) return Promise.resolve();
    if (hlsPromise) return hlsPromise;
    hlsPromise = new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/hls.js@1';
      s.onload = res; s.onerror = rej;
      document.head.appendChild(s);
    });
    return hlsPromise;
  }

  function markPlaying() {
    $$('.station').forEach(function (c) {
      var on = currentId === +c.getAttribute('data-id') && !audio.paused;
      c.classList.toggle('playing', on);
      var label = $('.play-label', c);
      if (label) label.textContent = on ? I.playing : I.listen;
    });
  }

  function fail() {
    var p = P();
    if (p.status) p.status.textContent = I.unavail;
    if (p.dot) p.dot.style.background = '#777';
    if (p.play) p.play.innerHTML = ICON_PLAY;
    toast(I.fail);
    markPlaying();
  }

  function playStation(id) {
    var s = byId[id], p = P();
    if (!s || !p.bar) return;
    if (currentId === id && !audio.paused) { audio.pause(); return; }
    currentId = id;
    lastTrack = '';
    p.bar.classList.add('open');
    document.body.classList.add('player-open');
    p.name.textContent = s.name;
    p.status.textContent = I.loading;
    p.dot.style.background = '#f39c7d';
    p.logo.textContent = s.init;
    if (s.logo) {
      var im = new Image();
      im.alt = '';
      im.referrerPolicy = 'no-referrer';
      im.onload = function () { if (currentId === id) { p.logo.textContent = ''; p.logo.appendChild(im); } };
      im.src = s.logo;
    }
    p.play.innerHTML = '<span class="spin"></span>';
    if (hls) { hls.destroy(); hls = null; }
    audio.pause(); audio.removeAttribute('src'); audio.load();

    if (/\.m3u8(\?|$)/.test(s.stream) && !audio.canPlayType('application/vnd.apple.mpegurl')) {
      loadHls().then(function () {
        if (currentId !== id) return;
        if (!window.Hls || !Hls.isSupported()) return fail();
        hls = new Hls();
        hls.loadSource(s.stream);
        hls.attachMedia(audio);
        hls.on(Hls.Events.MANIFEST_PARSED, function () { audio.play().catch(fail); });
        hls.on(Hls.Events.ERROR, function (_, d) { if (d && d.fatal) fail(); });
      }).catch(fail);
    } else {
      audio.src = s.stream;
      audio.play().catch(fail);
    }

    renderTrack();
    pollNP();
    pushRecent(id);
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.setActionHandler('play', function () { audio.play(); });
        navigator.mediaSession.setActionHandler('pause', function () { audio.pause(); });
        navigator.mediaSession.setActionHandler('stop', stop);
      } catch (e) {}
    }
    markPlaying();
  }

  function stop() {
    var p = P();
    audio.pause();
    if (hls) { hls.destroy(); hls = null; }
    audio.removeAttribute('src'); audio.load();
    currentId = null;
    lastTrack = '';
    clearInterval(npTimer);
    if (p.bar) { p.bar.classList.remove('open'); p.bar.classList.remove('playing'); }
    renderTrack();
    document.body.classList.remove('player-open');
    markPlaying();
  }

  audio.addEventListener('playing', function () {
    var p = P();
    if (p.status) p.status.textContent = I.live;
    if (p.dot) p.dot.style.background = '#4ade80';
    if (p.play) p.play.innerHTML = ICON_PAUSE;
    if (p.bar) p.bar.classList.add('playing');
    markPlaying();
  });
  audio.addEventListener('pause', function () {
    var p = P();
    if (currentId && p.status) p.status.textContent = I.paused;
    if (p.play) p.play.innerHTML = ICON_PLAY;
    if (p.bar) p.bar.classList.remove('playing');
    markPlaying();
  });
  audio.addEventListener('error', function () { if (currentId && audio.getAttribute('src')) fail(); });

  /* ================= directory (home) ================= */
  var favs = [], filter = 'all', query = '', cards = [], st;
  function norm(s) { return (s || '').toLowerCase().trim(); }
  function applyFilter() {
    var shown = 0;
    cards.forEach(function (c) {
      var id = +c.getAttribute('data-id');
      var ok = true;
      if (filter === 'fav') ok = favs.indexOf(id) > -1;
      else if (filter.indexOf('cat:') === 0) ok = c.getAttribute('data-cat') === filter.slice(4);
      else if (filter.indexOf('lang:') === 0) ok = c.getAttribute('data-lang').indexOf(filter.slice(5)) > -1;
      if (ok && query) ok = c.getAttribute('data-search').indexOf(query) > -1;
      c.hidden = !ok;
      if (ok) shown++;
    });
    var countEl = $('#countTxt'), emptyEl = $('#emptyBox');
    if (countEl) countEl.textContent = shown;
    if (emptyEl) emptyEl.hidden = shown > 0;
  }
  function setFavUi(btn, on) { btn.setAttribute('aria-pressed', on ? 'true' : 'false'); }
  function initGrid() {
    var grid = $('#stationGrid');
    filter = 'all'; query = '';
    cards = grid ? $$('.station', grid) : [];
    if (!grid) return;
    try { favs = JSON.parse(lsGet('rm_favs') || '[]'); } catch (e) { favs = []; }
    cards.forEach(function (c) {
      var id = +c.getAttribute('data-id');
      var f = $('.fav', c);
      if (f) setFavUi(f, favs.indexOf(id) > -1);
      var img = $('.logo img', c);
      if (img) img.addEventListener('error', function () { img.remove(); });
    });
    applyFilter();
  }

  /* ================= Google Play banner + popup ================= */
  var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var pmLastFocus = null, pmTimer = null;
  function openPlay(auto) {
    var m = $('#playModal');
    if (!m || m.classList.contains('open')) return;
    pmLastFocus = document.activeElement;
    m.classList.add('open'); m.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('pm-lock');
    var c = $('.pm-x', m); if (c) c.focus();
    ssSet('rm_pm', '1');
  }
  function closePlay() {
    var m = $('#playModal');
    if (!m) return;
    m.classList.remove('open'); m.setAttribute('aria-hidden', 'true');
    document.documentElement.classList.remove('pm-lock');
    if (pmLastFocus && pmLastFocus.focus) { try { pmLastFocus.focus(); } catch (e) {} }
  }
  function playModalInit() {
    clearTimeout(pmTimer);
    var m = $('#playModal');
    if (!m || isBot || isIOS || ssGet('rm_pm') || m.getAttribute('data-auto') !== '1') return;
    var delay = +m.getAttribute('data-delay') || 8000;
    pmTimer = setTimeout(function wait() {
      if (ssGet('rm_pm')) return;
      if (document.hidden || currentId || document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) { pmTimer = setTimeout(wait, 4000); return; }
      openPlay(true);
    }, delay);
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePlay(); });

  /* ================= common page behaviours ================= */
  var clockTimer = null, scrollFn = null, cookieBound = false;
  function tick() {
    var clock = $('#clock');
    if (!clock) return;
    try {
      clock.textContent = new Date().toLocaleTimeString('en-GB', { timeZone: 'Africa/Casablanca', hour: '2-digit', minute: '2-digit' });
    } catch (e) { clock.textContent = ''; }
  }

  function langSupported() {
    var S = ['ar', 'fr', 'en'], pref = lsGet('rm_lang');
    if (pref && S.indexOf(pref) > -1) return pref;
    var L = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'en'];
    for (var i = 0; i < L.length; i++) { var c = String(L[i]).toLowerCase().split('-')[0]; if (S.indexOf(c) > -1) return c; }
    return 'en';
  }

  function langBar() {
    $$('.langbar').forEach(function (b) { b.remove(); });
    if (isBot) return;
    var cur = (document.documentElement.lang || 'ar').toLowerCase().split('-')[0];
    var alts = {};
    $$('link[rel="alternate"][hreflang]', document.head).forEach(function (l) {
      var h = l.getAttribute('hreflang'); if (h !== 'x-default') alts[h] = l.getAttribute('href');
    });
    var want = langSupported();
    if (!want || want === cur || !alts[want]) return;
    if (ssGet('rm_langbar')) return;
    var T = { ar: ['هذه الصفحة متوفرة بالعربية.', 'انتقل إلى العربية'], fr: ['Cette page est disponible en français.', 'Voir en français'], en: ['This page is also available in English.', 'View in English'] }[want];
    var bar = document.createElement('div');
    bar.className = 'langbar'; bar.setAttribute('role', 'region'); bar.setAttribute('lang', want); bar.setAttribute('dir', want === 'ar' ? 'rtl' : 'ltr');
    bar.innerHTML = '<span></span><a></a><button type="button" aria-label="×" data-langbar-close>×</button>';
    bar.firstChild.textContent = T[0];
    var link = bar.children[1]; link.textContent = T[1]; link.href = alts[want]; link.setAttribute('hreflang', want); link.setAttribute('lang', want);
    document.body.insertBefore(bar, document.body.firstChild);
  }

  function promoInit() {
    var promo = $('#promo');
    if (!promo) return;
    if (!lsGet('rm_promo')) setTimeout(function () { promo.classList.add('show'); }, 2500);
    else promo.remove();
  }

  function initPage() {
    var menuBtn = $('#menuBtn'), nav = $('#mainNav');
    if (menuBtn && nav) {
      menuBtn.addEventListener('click', function () {
        var open = nav.classList.toggle('open');
        menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    }
    clearInterval(clockTimer);
    if ($('#clock')) { tick(); clockTimer = setInterval(tick, 20000); }

    var cookie = $('#cookieBar');
    if (cookie && !cookieBound && !lsGet('rm_cookie')) { cookie.classList.add('show'); cookieBound = true; }

    if (scrollFn) { window.removeEventListener('scroll', scrollFn); scrollFn = null; }
    var bar2 = $('#progress'), prose = $('.prose');
    if (bar2 && prose) {
      scrollFn = function () {
        var r = prose.getBoundingClientRect(), total = r.height - window.innerHeight * 0.6;
        var pct = Math.min(100, Math.max(0, (-r.top / Math.max(total, 1)) * 100));
        bar2.style.width = pct + '%';
      };
      window.addEventListener('scroll', scrollFn, { passive: true }); scrollFn();
    }
    initGrid();
    promoInit();
    langBar();
    renderRecent();
    renderTrack();
    markPlaying();
    playModalInit();
  }

  /* ================= delegated clicks ================= */
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var play = t.closest('[data-play]');
    if (play) { playStation(+play.getAttribute('data-play')); return; }
    if (t.closest('#heroPlay')) { playStation(1); return; }
    if (t.closest('#playBtn')) {
      if (!currentId) return playStation(1);
      if (audio.paused) audio.play().catch(fail); else audio.pause();
      return;
    }
    if (t.closest('#stopBtn')) { stop(); return; }
    if (t.closest('[data-open-play]')) { e.preventDefault(); openPlay(false); return; }
    if (t.closest('[data-close-play]')) { closePlay(); return; }
    if (t.classList && t.classList.contains('pm')) { closePlay(); return; }
    var bx = t.closest('[data-close-banner]');
    if (bx) { lsSet('rm_appbanner', String(Date.now() + 7 * 864e5)); document.documentElement.classList.add('no-appbanner'); return; }
    var fav = t.closest('.fav');
    if (fav) {
      var id = +fav.getAttribute('data-fav');
      var i = favs.indexOf(id);
      if (i > -1) favs.splice(i, 1); else favs.push(id);
      lsSet('rm_favs', JSON.stringify(favs));
      setFavUi(fav, i === -1);
      toast(i === -1 ? I.fav_add : I.fav_del);
      if (filter === 'fav') applyFilter();
      return;
    }
    var chip = t.closest('.chip');
    if (chip) {
      $$('.chip').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
      chip.setAttribute('aria-pressed', 'true');
      filter = chip.getAttribute('data-filter');
      applyFilter();
      return;
    }
    var cp = t.closest('[data-copy]');
    if (cp) {
      var u = cp.getAttribute('data-copy');
      var done = function () { toast(I.copied); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(u).then(done, done); else done();
      return;
    }
    if (t.closest('#cookieOk')) { lsSet('rm_cookie', '1'); var cb = $('#cookieBar'); if (cb) cb.classList.remove('show'); return; }
    if (t.closest('#promoClose')) { var pr = $('#promo'); if (pr) pr.classList.remove('show'); lsSet('rm_promo', '1'); return; }
    if (t.closest('[data-langbar-close]')) { var lb = t.closest('.langbar'); if (lb) lb.remove(); ssSet('rm_langbar', '1'); return; }
    var po = t.closest('[data-privacy-opts]');
    if (po) {
      try {
        if (window.googlefc && window.googlefc.callbackQueue && window.googlefc.showRevocationMessage) {
          e.preventDefault();
          window.googlefc.callbackQueue.push(window.googlefc.showRevocationMessage);
        }
      } catch (x) {}
      return;
    }
    var lg = t.closest('a[hreflang][lang]');
    if (lg) lsSet('rm_lang', lg.getAttribute('hreflang'));
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t && t.id === 'volRange') { audio.volume = Math.max(0, Math.min(1, +t.value / 100)); lsSet('rm_vol', t.value); return; }
    if (t && t.id === 'mainSearch') {
      clearTimeout(st);
      st = setTimeout(function () { query = norm(t.value); applyFilter(); }, 120);
    }
  });

  /* ================= keep playing while navigating =================
     Only while a station is loaded: internal links are fetched and swapped in place, so the
     audio element is never torn down. With nothing playing, every link is a normal page load
     (crawlers, ads and analytics see ordinary pages). */
  var SWAP_HEAD = ['meta[name="description"]', 'link[rel="canonical"]', 'meta[property^="og:"]', 'meta[name^="twitter:"]', 'link[rel="alternate"][hreflang]', 'script[type="application/ld+json"]'];
  var lastPath = location.pathname + location.search;

  function swapNode(sel, doc) {
    var a = $(sel), b = doc.querySelector(sel);
    if (a && b) a.replaceWith(document.importNode(b, true));
  }

  function syncHead(doc) {
    SWAP_HEAD.forEach(function (sel) {
      $$(sel, document.head).forEach(function (n) { n.remove(); });
      $$(sel, doc.head).forEach(function (n) { document.head.appendChild(document.importNode(n, true)); });
    });
  }

  function swap(doc, u, push) {
    $$('script:not([src])', doc).forEach(function (sc) {
      var m = /window\.RM_I18N=(\{.*\});/.exec(sc.textContent);
      if (m) { try { I = JSON.parse(m[1]); window.RM_I18N = I; } catch (e) {} }
      var l = /window\.RM_LANG="(\w+)"/.exec(sc.textContent);
      if (l) window.RM_LANG = l[1];
    });
    document.title = doc.title;
    syncHead(doc);
    document.documentElement.lang = doc.documentElement.lang;
    document.documentElement.dir = doc.documentElement.dir;
    swapNode('a.skip', doc);
    swapNode('header.top', doc);
    swapNode('main#main', doc);
    swapNode('footer.foot', doc);
    var po = $('#promo'); if (po) po.remove();
    var np = doc.querySelector('#promo'), hdr = $('header.top');
    if (np && hdr && !lsGet('rm_promo')) hdr.parentNode.insertBefore(document.importNode(np, true), hdr.nextSibling);
    readStations(doc);
    var nb = doc.querySelector('#playerBar'), p = P();
    if (nb && p.bar) {
      p.bar.setAttribute('aria-label', nb.getAttribute('aria-label') || '');
      var pb = $('#playBtn', nb), sb = $('#stopBtn', nb);
      if (pb && p.play) p.play.setAttribute('aria-label', pb.getAttribute('aria-label') || '');
      if (sb && $('#stopBtn')) $('#stopBtn').setAttribute('aria-label', sb.getAttribute('aria-label') || '');
      if (!currentId) { p.name.textContent = $('#pName', nb).textContent; p.status.textContent = $('#pStatus', nb).textContent; }
    }
    var nc = doc.querySelector('#cookieBar'), oc = $('#cookieBar');
    if (nc && oc && oc.classList.contains('show')) oc.innerHTML = nc.innerHTML;
    if (push) history.pushState({ rm: 1 }, '', u.pathname + u.search + u.hash);
    lastPath = u.pathname + u.search;
    if (u.hash && $(u.hash)) $(u.hash).scrollIntoView(); else window.scrollTo(0, 0);
    initPage();
    var main = $('main#main'); if (main) { main.setAttribute('tabindex', '-1'); try { main.focus({ preventScroll: true }); } catch (e) {} }
    try {
      if (window.gtag) window.gtag('event', 'page_view', { page_title: document.title, page_location: location.href });
      else if (window.dataLayer) window.dataLayer.push({ event: 'rm_page_view', page_path: location.pathname });
    } catch (e) {}
  }

  function navigate(href, push) {
    var u = new URL(href, location.href);
    document.documentElement.classList.add('rm-loading');
    fetch(u.href, { credentials: 'same-origin' }).then(function (r) {
      var ct = r.headers.get('content-type') || '';
      if (!r.ok || ct.indexOf('text/html') < 0) throw new Error('not html');
      return r.text();
    }).then(function (txt) {
      var doc = new DOMParser().parseFromString(txt, 'text/html');
      if (!doc.querySelector('main#main')) throw new Error('no main');
      swap(doc, u, push);
      document.documentElement.classList.remove('rm-loading');
    }).catch(function () { location.href = u.href; });
  }

  document.addEventListener('click', function (e) {
    if (!currentId || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('data-privacy-opts')) return;
    var u = new URL(a.href, location.href);
    if (u.origin !== location.origin || (u.protocol !== 'http:' && u.protocol !== 'https:')) return;
    if (u.pathname === location.pathname && u.search === location.search) {
      if (u.hash) return;
      e.preventDefault(); window.scrollTo(0, 0); return;
    }
    if (/\.(xml|json|txt|jpe?g|png|gif|svg|webp|zip|pdf|webmanifest|js|css|ico|mp3)$/i.test(u.pathname)) return;
    e.preventDefault();
    navigate(u.href, true);
  });

  window.addEventListener('popstate', function () {
    var now = location.pathname + location.search;
    if (now === lastPath) return;
    if (currentId) navigate(location.href, false); else location.reload();
  });

  /* ================= start ================= */
  readStations(document);
  var vr = $('#volRange'), sv = lsGet('rm_vol');
  if (sv !== null) { audio.volume = Math.max(0, Math.min(1, +sv / 100)); if (vr) vr.value = sv; }
  initPage();
})();
