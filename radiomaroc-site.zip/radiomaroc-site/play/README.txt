Put your Google Play screenshots here (shot-1.jpg, shot-2.jpg, ...), then list them in data/play.json under "screenshots" and rebuild.
