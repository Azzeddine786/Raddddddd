# -*- coding: utf-8 -*-
OLD_TX = {}

OLD_TX['amazigh'] = dict(
 fr=dict(title="La radio amazighe au Maroc : langue, identité et musique sur les ondes",
  mt='La radio amazighe au Maroc | Radio Maroc',
  desc="L'amazigh dans la radio marocaine : les trois variantes, le rôle de la radio dans la préservation de la langue, la musique amazighe et comment l'écouter et l'apprendre.",
  kw='radio amazighe maroc, radio tamazight, radio azawan, écouter radio amazigh, musique amazighe radio',
  body='''<p>L'amazigh est l'une des plus anciennes langues et cultures d'Afrique du Nord, présente au Maroc à la maison, au souk, dans la chanson et le conte. La radio joue un grand rôle pour préserver cette langue et la transmettre entre les générations, car la radio repose sur la parole, domaine le plus proche d'une langue qui se transmettait oralement avant d'être écrite et enseignée à grande échelle.</p>
<p>Cet article présente un aperçu de l'amazigh dans le paysage radiophonique marocain : ses variantes, le rôle de la radio à son service, les types de musique et d'émissions amazighes, et comment en profitent ceux qui parlent amazigh et ceux qui veulent le découvrir ou l'apprendre. Nous avons veillé à ne citer que des informations générales connues, et nous vous invitons à consulter les institutions spécialisées pour approfondir.</p>
<h2>L'amazigh au Maroc : un aperçu rapide</h2>
<p>Les Marocains utilisent l'amazigh dans trois variantes principales bien connues :</p>
<ul><li><strong>Le tarifit :</strong> dans la région du Rif, au nord du Maroc.</li><li><strong>Le tamazight :</strong> dans le Moyen Atlas et ses environs.</li><li><strong>Le tachelhit :</strong> dans le Souss, le Haut Atlas et le sud.</li></ul>
<p>Les Marocains écrivent l'amazigh en caractères tifinagh, une écriture enseignée et utilisée sur les panneaux officiels. La Constitution de 2011 a établi que l'amazigh est une langue officielle de l'État aux côtés de l'arabe, ce qui a encouragé sa présence dans l'éducation et les médias. L'État a aussi déclaré le Nouvel An amazigh jour férié officiel à partir de 2024, après une décision royale en 2023.</p>
<h2>Quel est le rôle de la radio au service de l'amazigh ?</h2>
<h3>1. Préserver la langue parlée</h3>
<p>Les variantes de l'amazigh sont avant tout des langues de conversation, de contes et de chansons, et la radio les garde vivantes dans la bouche de leurs locuteurs : présentateurs, auditeurs qui appellent et invités parlent leur parler d'origine, que les jeunes et les enfants entendent à l'étranger et en ville.</p>
<h3>2. Relier les générations</h3>
<p>Le grand-père et le petit-fils écoutent la même émission, ce qui permet de transmettre vocabulaire, proverbes et récits. Dans les villages et les zones de montagne, la radio est souvent le moyen le plus proche et le moins cher d'accéder à la langue maternelle.</p>
<h3>3. Donner une tribune à l'artiste et au créateur</h3>
<p>La radio permet aux chanteurs, aux poètes et aux groupes locaux d'atteindre un public que d'autres moyens n'atteignent pas, et donne à des styles comme les rwayes, l'ahouach et la chanson amazighe moderne un espace pour se diffuser.</p>
<h3>4. Le service public</h3>
<p>Les émissions amazighes rendent un service utile en santé, éducation, agriculture et sensibilisation dans une langue que l'auditeur comprend facilement, un effet pratique qui dépasse l'aspect culturel.</p>
<h2>Qu'entend-on à la radio amazighe ?</h2>
<ul><li><strong>La chanson amazighe :</strong> du patrimoine à la chanson moderne, dans la diversité des rythmes et des variantes.</li><li><strong>Les émissions de débat et de société :</strong> des discussions sur les questions de la région, l'éducation et la culture.</li><li><strong>Les contes et les proverbes :</strong> des séquences qui conservent le récit oral.</li><li><strong>L'actualité :</strong> des bulletins en amazigh sur certains réseaux nationaux et régionaux.</li><li><strong>La religion et le patrimoine :</strong> des contenus religieux et culturels dans différentes variantes.</li></ul>
<p>Dans notre guide, vous trouvez des stations comme <strong>Radio Azawan</strong>, qui émet en amazigh, et <strong>Radio Atbir</strong>, qui mêle arabe et amazigh : un bon point de départ pour l'écoute.</p>
<h2>Comment l'écouter et en apprendre ?</h2>
<p>Si vous parlez amazigh, écoutez comme il vous plaît. Si vous voulez apprendre ou découvrir, suivez ces étapes :</p>
<ul><li><strong>Commencez par les chansons :</strong> le rythme facilite la mémorisation des mots, et votre oreille commence à distinguer les sons.</li><li><strong>Choisissez une seule variante :</strong> ne mélangez pas les variantes au début, chacune a son vocabulaire.</li><li><strong>Notez les mots répétés :</strong> comme la salutation, le remerciement et les nombres, et cherchez leur sens.</li><li><strong>Écoutez une demi-heure par jour :</strong> la régularité compte plus que la durée.</li><li><strong>Associez la radio à une source écrite :</strong> comme un dictionnaire, un manuel ou le site d'une institution spécialisée.</li><li><strong>Parlez, même un peu :</strong> essayez des phrases simples avec des locuteurs : c'est le chemin le plus rapide pour progresser.</li></ul>
<p>La radio seule n'enseigne pas une langue entière, mais elle entraîne l'oreille et vous rapproche du vrai rythme de la langue telle qu'on la parle dans la vie des gens.</p>
<h2>L'amazigh et la diaspora</h2>
<p>Beaucoup de familles marocaines à l'étranger parlent amazigh à la maison et craignent que leurs enfants oublient leur langue. La radio sur Internet est une solution simple : lancez une station amazighe dans la cuisine ou la voiture et faites-en une part de l'ambiance familiale. Pour connaître les meilleures méthodes, lisez <a href="{link:abroad}">écouter les radios marocaines depuis l'étranger</a>.</p>
<h2>Les défis des médias amazighs</h2>
<p>Malgré les progrès, les médias amazighs rencontrent des difficultés connues : le manque de cadres spécialisés et de financement, l'inégalité des contenus entre les variantes et la concurrence des plateformes mondiales. Parmi les solutions proposées : soutenir la production locale, former des journalistes et des présentateurs et élargir la présence numérique par les podcasts et les plateformes. L'auditeur a aussi un rôle : écouter, interagir et partager les bonnes émissions.</p>
<h2>Sujets connexes</h2>
<p>L'amazigh croise les radios régionales qui proposent un contenu dans le parler de la région, ce que nous avons détaillé dans le <a href="{link:regional}">guide des radios régionales marocaines</a>. Pour connaître le parcours de la radio au Maroc en général, lisez <a href="{link:history}">histoire de la radio marocaine</a>.</p>
<h2>Corriger des idées reçues</h2>
<ul><li><strong>L'amazigh n'est pas un « dialecte arabe » :</strong> c'est une langue indépendante qui a son système et son histoire, et qui se divise en variantes.</li><li><strong>Elles ne sont pas toutes identiques :</strong> un locuteur du tarifit peut ne pas comprendre tout ce que dit un locuteur du tachelhit, même si les variantes partagent beaucoup d'origines.</li><li><strong>Ce n'est pas seulement la langue des villages :</strong> des Marocains la parlent aussi dans les grandes villes et à l'étranger.</li><li><strong>Ce n'est pas seulement une langue orale :</strong> elle a une écriture, le tifinagh, et elle est enseignée dans les institutions.</li></ul>
<h2>Des mots pour commencer</h2>
<p>Si vous voulez commencer par des mots simples, vous entendrez souvent « azul », qui signifie salut ou salutation, et « tanmmirt », qui signifie merci. Ce sont des exemples généraux dont la forme peut varier selon la variante : ne les prenez pas pour un dictionnaire. Écoutez comment on les prononce dans les émissions, puis cherchez la forme correcte dans une référence fiable.</p>
<h2>Comment soutenir l'amazigh dans les médias ?</h2>
<ul><li>Écoutez les émissions amazighes et partagez-les avec vos amis.</li><li>Interagissez avec les stations par un message ou un commentaire positif.</li><li>Achetez ou écoutez, par des canaux légitimes, la musique des artistes amazighs.</li><li>Apprenez à vos enfants à écouter la langue maternelle à la maison.</li></ul>
<h2>Questions fréquentes</h2>
<details class="faq"><summary>L'amazigh est-il une seule langue ?</summary><p>C'est une langue qui a plusieurs variantes au Maroc, dont les plus connues sont le tarifit, le tamazight et le tachelhit. Il existe aussi une langue standard enseignée à l'école. Nous ne sommes pas une instance scientifique et conseillons donc de consulter l'Institut Royal de la Culture Amazighe pour les détails linguistiques.</p></details>
<details class="faq"><summary>Trouve-t-on des stations amazighes dans votre guide ?</summary><p>Oui : Radio Azawan, Radio Atbir et d'autres, et nous travaillons à en ajouter. Si vous connaissez une station, proposez-la via la <a href="{link:contact}">page Contact</a>.</p></details>
<details class="faq"><summary>Puis-je apprendre l'amazigh en écoutant seulement ?</summary><p>L'écoute aide beaucoup à entraîner l'oreille mais ne suffit pas seule. Associez-la à la lecture, à la conversation et à des sources pédagogiques.</p></details>
<h2>En résumé</h2>
<p>La radio amazighe est une voix vivante d'une culture ancienne, un moyen simple de préserver la langue et de relier les générations. Que vous soyez locuteur, apprenant ou amateur de musique, vous trouverez dans le guide des stations qui méritent d'être essayées, et votre écoute et votre participation les soutiennent.</p>'''),
 en=dict(title='Amazigh Radio in Morocco: Language, Identity and Music on the Airwaves',
  mt='Amazigh Radio in Morocco | Radio Maroc',
  desc='Amazigh in Moroccan radio: the three varieties, radio’s role in keeping the language alive, Amazigh music and how to listen and learn.',
  kw='Amazigh radio Morocco, Tamazight radio, Radio Azawan, listen to Amazigh radio, Amazigh music radio',
  body='''<p>Amazigh is one of the oldest languages and cultures of North Africa, present in Morocco at home, in the souk, in song and in story. Radio plays a big part in keeping this language alive and passing it between generations, because radio is built on the spoken word, the field closest to a language that was passed on orally before it was written down and taught on a wide scale.</p>
<p>This article gives an overview of Amazigh in Morocco’s radio landscape: its varieties, radio’s role in serving it, the types of Amazigh music and programs, and how Amazigh speakers and people who want to get to know or learn it can benefit. We have taken care to state only well-known general information, and we invite you to consult specialised institutions to go further.</p>
<h2>Amazigh in Morocco: a quick overview</h2>
<p>Moroccans use Amazigh in three well-known main varieties:</p>
<ul><li><strong>Tarifit:</strong> in the Rif region in northern Morocco.</li><li><strong>Tamazight:</strong> in the Middle Atlas and around it.</li><li><strong>Tashelhit:</strong> in the Souss, the High Atlas and the south.</li></ul>
<p>Moroccans write Amazigh in the Tifinagh script, which is taught and used on official signs. The 2011 Constitution set out that Amazigh is an official language of the state alongside Arabic, which encouraged its presence in education and media. The state also declared the Amazigh New Year an official holiday from 2024, following a royal decision in 2023.</p>
<h2>What is radio’s role in serving Amazigh?</h2>
<h3>1. Keeping the spoken language</h3>
<p>The Amazigh varieties are above all languages of conversation, stories and songs, and radio keeps them alive on the lips of their speakers: presenters, callers and guests speak in their original dialects, which young people and children hear abroad and in the cities.</p>
<h3>2. Linking generations</h3>
<p>Grandfather and grandchild listen to the same program, a chance to pass on vocabulary, proverbs and stories. In villages and mountain areas, radio is often the closest and cheapest way to reach the mother tongue.</p>
<h3>3. Giving artists and creators a platform</h3>
<p>Radio lets singers, poets and local groups reach an audience other media do not, and gives styles such as the rwayes, ahouach and modern Amazigh song room to spread.</p>
<h3>4. Public service</h3>
<p>Amazigh programs offer a useful service in health, education, agriculture and awareness in a language the listener understands easily, a practical effect that goes beyond the cultural side.</p>
<h2>What do you hear on Amazigh radio?</h2>
<ul><li><strong>Amazigh song:</strong> from heritage to modern song, with a variety of rhythms and varieties.</li><li><strong>Talk and community programs:</strong> discussions about regional issues, education and culture.</li><li><strong>Stories and proverbs:</strong> segments that keep oral storytelling alive.</li><li><strong>News:</strong> bulletins in Amazigh on some national and regional networks.</li><li><strong>Religion and heritage:</strong> religious and cultural material in different varieties.</li></ul>
<p>In our directory you will find stations such as <strong>Radio Azawan</strong>, which broadcasts in Amazigh, and <strong>Radio Atbir</strong>, which mixes Arabic and Amazigh, a good starting point for listening.</p>
<h2>How to listen and learn from it</h2>
<p>If you speak Amazigh, listen as you like. If you want to learn or get to know it, follow these steps:</p>
<ul><li><strong>Start with songs:</strong> rhythm makes it easier to remember words, and your ear begins to tell the sounds apart.</li><li><strong>Choose one variety:</strong> do not mix varieties at first, as each has its own vocabulary.</li><li><strong>Note repeated words:</strong> such as greetings, thanks and numbers, and look up their meanings.</li><li><strong>Listen half an hour a day:</strong> regularity matters more than length.</li><li><strong>Pair radio with a written source:</strong> such as a dictionary, a course book or the website of a specialised institution.</li><li><strong>Speak, even a little:</strong> try simple sentences with speakers: it is the fastest way to improve.</li></ul>
<p>Radio alone does not teach a whole language, but it trains the ear and brings you closer to the real rhythm of the language as it is spoken in people’s lives.</p>
<h2>Amazigh and the diaspora</h2>
<p>Many Moroccan families abroad speak Amazigh at home and fear their children will forget their language. Internet radio is a simple answer: put on an Amazigh station in the kitchen or the car and make it part of the family atmosphere. To learn the best methods, read <a href="{link:abroad}">listening to Moroccan radio from abroad</a>.</p>
<h2>Challenges facing Amazigh media</h2>
<p>Despite progress, Amazigh media face known difficulties, including a shortage of specialised staff and funding, uneven content between varieties, and competition from global platforms. Proposed solutions include supporting local production, training journalists and presenters, and widening digital presence through podcasts and platforms. The listener has a role too: listening, interacting and sharing good programs.</p>
<h2>Related topics</h2>
<p>Amazigh overlaps with regional stations that offer content in the region’s dialect, which we detailed in the <a href="{link:regional}">guide to Morocco’s regional radio stations</a>. To learn about the journey of radio in Morocco in general, read <a href="{link:history}">a history of Moroccan radio</a>.</p>
<h2>Correcting common misconceptions</h2>
<ul><li><strong>Amazigh is not an “Arabic dialect”:</strong> it is an independent language with its own system and history, which branches into varieties.</li><li><strong>They are not all the same:</strong> a Tarifit speaker may not understand everything a Tashelhit speaker says, even if the varieties share many origins.</li><li><strong>It is not only a village language:</strong> Moroccans speak it in the big cities and abroad too.</li><li><strong>It is not only a spoken language:</strong> it has the Tifinagh script and is taught in institutions.</li></ul>
<h2>Words to start with</h2>
<p>If you want to start with simple words, you will hear “azul” often, meaning hello or greeting, and “tanmmirt”, meaning thank you. These are general examples whose forms may differ by variety, so do not treat them as a dictionary. Listen to how they are pronounced in programs, then look up the correct form in a reliable reference.</p>
<h2>How to support Amazigh in the media</h2>
<ul><li>Listen to Amazigh programs and share them with friends.</li><li>Interact with stations through a message or positive comment.</li><li>Buy or listen, through legitimate channels, to the music of Amazigh artists.</li><li>Teach your children to listen to the mother tongue at home.</li></ul>
<h2>Frequently asked questions</h2>
<details class="faq"><summary>Is Amazigh one language?</summary><p>It is a language with several varieties in Morocco, the best known being Tarifit, Tamazight and Tashelhit. There is also a standard language taught in schools. We are not a scientific body, so we suggest consulting the Royal Institute of Amazigh Culture for linguistic details.</p></details>
<details class="faq"><summary>Do you have Amazigh stations in your directory?</summary><p>Yes: Radio Azawan, Radio Atbir and others, and we are working to add more. If you know a station, suggest it through the <a href="{link:contact}">Contact page</a>.</p></details>
<details class="faq"><summary>Can I learn Amazigh just by listening?</summary><p>Listening helps a great deal in training the ear, but it is not enough on its own. Combine it with reading, speaking and learning resources.</p></details>
<h2>Conclusion</h2>
<p>Amazigh radio is a living voice of an ancient culture, a simple way to keep the language alive and link generations. Whether you are a speaker, a learner or a music lover, you will find stations in the directory worth trying, and your listening and participation support them.</p>'''))

OLD_TX['abroad'] = dict(
 fr=dict(title="Écouter les radios marocaines depuis l'étranger : le guide de la diaspora",
  mt='Écouter les radios marocaines depuis l’étranger | Radio Maroc',
  desc="Guide pratique pour la diaspora marocaine : écouter les radios marocaines depuis l'étranger, décalage horaire, restrictions géographiques et solutions.",
  kw='écouter radio marocaine étranger, radio maroc depuis la france, radio marocaine diaspora, radio maroc europe',
  body='''<p>Celui qui vit loin du Maroc sait que le son est parfois plus fort que l'image. Une chanson d'enfance, un bulletin en darija ou une émission du matin suffisent à vous ramener chez vous. Grâce à Internet, écouter les radios marocaines depuis l'Europe, l'Amérique ou le Golfe n'est plus difficile, mais des questions pratiques reviennent : toutes les stations fonctionnent-elles hors du Maroc ? Qu'en est-il du décalage horaire ? Et comment écouter en voiture là-bas ?</p>
<p>Nous avons réuni dans ce guide des réponses pratiques utiles surtout à la diaspora, mais aussi aux voyageurs, aux étudiants et aux travailleurs à l'étranger.</p>
<h2>Puis-je écouter les radios marocaines depuis n'importe quel pays ?</h2>
<p>Le plus souvent oui. La plupart des stations diffusent sur Internet pour un public mondial, et une connexion stable suffit. Mais deux cas peuvent bloquer certaines stations :</p>
<ul><li><strong>Les restrictions géographiques :</strong> certaines stations bloquent la diffusion hors du Maroc pour des raisons de droits de diffusion ou d'accords commerciaux.</li><li><strong>Le changement des liens :</strong> le lien du flux peut changer ou s'arrêter, et le message « flux indisponible » apparaît alors que le problème ne vient pas de votre pays.</li></ul>
<p>Si vous tombez sur une station qui ne marche pas, essayez d'abord une autre pour savoir si le problème est général, puis consultez le site officiel de la station. Si la panne persiste, signalez-la-nous via la <a href="{link:contact}">page Contact</a> pour que nous réparions le lien dans le guide.</p>
<h2>Et le VPN ?</h2>
<p>Certains demandent s'ils peuvent utiliser un VPN pour contourner les restrictions géographiques. Nous attirons ici l'attention sur deux points : le premier, c'est que l'écoute habituelle n'a pas besoin de VPN et que la plupart des stations fonctionnent sans ; le second, c'est que l'usage de ces services dépend des conditions de la station et des lois de votre pays de résidence, et nous ne conseillons pas de contourner des restrictions posées par les titulaires de droits. Si une station est bloquée, choisissez une alternative dans le guide.</p>
<h2>Le décalage horaire : comment savoir ce qui est diffusé maintenant ?</h2>
<p>Le Maroc utilise une heure qui peut différer entre l'été et l'hiver, et certains pays passent à l'heure d'été à d'autres dates. Le décalage entre vous et le Maroc peut donc changer au cours de l'année. Nos conseils :</p>
<ul><li>Cherchez « heure actuelle à Casablanca » pour connaître le décalage réel du jour.</li><li>Comparez la grille de la station (indiquée à l'heure du Maroc) avec votre heure locale.</li><li>Notez dans votre téléphone les horaires de vos émissions favorites à votre heure.</li><li>Rappelez-vous que l'actualité et les matchs en direct sont diffusés à l'heure du Maroc : calculez le décalage avant le match.</li></ul>
<h2>Les meilleures façons d'écouter à l'étranger</h2>
<h3>1. Directement depuis le site</h3>
<p>Ouvrez le <a href="{link:home}#radios">guide des stations</a> dans le navigateur et appuyez sur « Écouter ». Vous n'avez rien à installer et vous pouvez enregistrer vos favorites sur votre appareil.</p>
<h3>2. Une application sur le téléphone</h3>
<p>Les applications permettent la lecture en arrière-plan et le contrôle depuis l'écran de verrouillage. Vous trouvez l'<a href="https://play.google.com/store/apps/details?id=com.maradioazdhj.radiomoroccoandab" target="_blank" rel="noopener">application Radio Maroc sur Google Play</a> pour les utilisateurs Android. Si vous avez un iPhone, le navigateur est un bon choix, et il existe aussi des applications de radios mondiales connues.</p>
<h3>3. À la maison : téléviseur et enceintes connectées</h3>
<p>Ouvrez le guide sur le téléviseur connecté ou envoyez le son de votre téléphone vers une enceinte en Bluetooth. C'est une bonne façon de réunir la famille autour d'une radio marocaine le soir. Voir notre <a href="{link:smart-speaker}">guide des enceintes connectées</a>.</p>
<h3>4. En voiture</h3>
<p>Reliez votre téléphone à la voiture par Bluetooth, par câble ou via Android Auto et Apple CarPlay. Veillez à choisir la station avant de conduire. Pour en savoir plus, lisez <a href="{link:car}">comment choisir sa radio pour la voiture ou le téléphone</a>.</p>
<h2>La consommation de données en déplacement</h2>
<p>Si vous utilisez les données du téléphone dans un pays qui n'est pas le vôtre, soyez attentif au coût de l'itinérance (roaming). Une heure d'écoute à qualité moyenne consomme des dizaines de mégaoctets, et la consommation peut s'accumuler vite. Utilisez le Wi-Fi dès que possible, choisissez une qualité moindre si nécessaire et surveillez votre forfait.</p>
<h2>Des stations adaptées à la diaspora</h2>
<ul><li><strong>Pour l'actualité :</strong> Medi 1 Radio pour suivre les affaires marocaines et maghrébines.</li><li><strong>Pour la musique :</strong> Hit Radio, Chada FM et les chaînes musicales de Medi 1.</li><li><strong>Pour le patrimoine :</strong> la chaîne andalouse, le tarab et le melhoun quand ils sont disponibles.</li><li><strong>Pour la langue amazighe :</strong> Radio Azawan et Radio Atbir, et voyez <a href="{link:amazigh}">la radio amazighe au Maroc</a>.</li><li><strong>Pour le Coran et la sérénité :</strong> la radio du Saint Coran et la chaîne soufie.</li><li><strong>Pour votre région :</strong> la radio de votre ville ou région si elle existe, pour entendre son actualité et son parler.</li></ul>
<p>Si vous vivez en France ou ailleurs en Europe, voyez aussi notre guide des <a href="{link:french-radio}">radios marocaines en français</a>.</p>
<h2>La radio et l'éducation des enfants à la langue et à l'identité</h2>
<p>Beaucoup de parents s'inquiètent de la faiblesse de leurs enfants en darija, en arabe ou en amazigh. La radio est un outil simple : elle met la langue dans l'oreille de l'enfant sans pression. Lancez une station marocaine dans la voiture sur le chemin de l'école, ou dans la cuisine à l'heure du dîner, et discutez de ce que vous avez entendu. Avec le temps, l'enfant s'habituera au rythme et au vocabulaire. Cela ne remplace pas la conversation quotidienne et la lecture, mais les renforce.</p>
<h2>Des conseils pratiques</h2>
<ul><li>Enregistrez trois stations en favoris pour y accéder vite.</li><li>Prévoyez une solution de repli si une station s'arrête, ne comptez pas sur une seule.</li><li>Utilisez de bons écouteurs si vous êtes au travail.</li><li>Vérifiez votre connexion avant d'incriminer la station.</li><li>Consultez les grilles à votre heure locale.</li></ul>
<h2>Une routine hebdomadaire suggérée pour la famille marocaine à l'étranger</h2>
<ul><li><strong>Le matin en semaine :</strong> un bulletin bref en darija ou en français au petit-déjeuner.</li><li><strong>Le soir en semaine :</strong> une musique calme pendant le dîner.</li><li><strong>Le samedi :</strong> une chaîne musicale légère pour les tâches ménagères et le nettoyage.</li><li><strong>Le dimanche :</strong> une émission de débat ou culturelle pendant la cuisine en famille.</li><li><strong>Le vendredi :</strong> la radio du Coran ou la chaîne soufie pour une ambiance spirituelle.</li></ul>
<p>Cette organisation fait de la radio une part stable du rythme familial, que les enfants apprivoisent comme les repas.</p>
<h2>Études et travail à l'étranger</h2>
<p>Si vous êtes étudiant ou travailleur loin de votre famille, la radio atténue le sentiment de solitude et vous garde en lien avec l'actualité et la langue. Mais ne la laissez pas vous distraire de vos études : utilisez-la pendant les pauses ou les déplacements. Si vous avez besoin de concentration, choisissez une chaîne musicale calme sans paroles.</p>
<h2>Rester en sécurité sur le numérique</h2>
<ul><li>Utilisez un navigateur à jour et évitez les sites qui demandent vos données pour lancer la radio.</li><li>Ne saisissez ni numéros de carte ni mots de passe sur un site qui prétend « débloquer » des stations bloquées.</li><li>Téléchargez les applications depuis les boutiques officielles.</li></ul>
<h2>Questions fréquentes</h2>
<details class="faq"><summary>Pourquoi une station précise ne marche-t-elle pas chez moi ?</summary><p>La cause peut être une restriction géographique ou l'arrêt du serveur. Essayez une autre station, puis réessayez plus tard et signalez-nous le problème.</p></details>
<details class="faq"><summary>Ai-je besoin d'une application ?</summary><p>Non, le navigateur suffit, mais l'application convient mieux à l'écoute quotidienne et à la lecture en arrière-plan.</p></details>
<details class="faq"><summary>L'écoute depuis l'étranger est-elle gratuite ?</summary><p>Le guide est gratuit ; vous ne payez que l'Internet auprès de votre fournisseur.</p></details>
<h2>En résumé</h2>
<p>La radio marocaine en exil n'est pas un luxe : c'est un fil qui vous relie à votre langue, à votre mémoire et à l'actualité de votre pays. Choisissez la façon d'écouter qui vous convient, soyez attentif au décalage horaire et à la consommation de données, et vous trouverez dans notre guide de quoi rapprocher le Maroc d'un geste.</p>'''),
 en=dict(title='Listening to Moroccan Radio from Abroad: A Guide for the Diaspora',
  mt='Listening to Moroccan Radio from Abroad | Radio Maroc',
  desc='A practical guide for the Moroccan diaspora: how to listen to Moroccan radio from Europe, the Americas and beyond, with time differences, regional restrictions and fixes.',
  kw='listen to Moroccan radio abroad, Moroccan radio from Europe, Moroccan diaspora radio, Moroccan radio online abroad',
  body='''<p>Anyone living far from Morocco knows that sound is sometimes stronger than a picture. A song from childhood, a bulletin in Darija or a morning program is enough to bring home back. Thanks to the internet, listening to Moroccan radio from Europe, America or the Gulf is no longer hard, but some practical questions keep coming up: do all stations work outside Morocco? What about time differences? And how do I listen in the car over there?</p>
<p>We have gathered practical answers in this guide that help the diaspora in particular, and also suit travelers, students and people working abroad.</p>
<h2>Can I listen to Moroccan radio from any country?</h2>
<p>Usually yes. Most stations stream online to a worldwide audience, and a steady connection is enough. But two cases may block some stations:</p>
<ul><li><strong>Regional restrictions:</strong> some stations block streaming outside Morocco for reasons of broadcasting rights or commercial agreements.</li><li><strong>Changing links:</strong> the stream link may change or stop, and “stream unavailable” appears even though the problem is not in your country.</li></ul>
<p>If you run into a station that does not work, try another one first to see whether the problem is general, then check the station’s official website. If the fault continues, tell us through the <a href="{link:contact}">Contact page</a> so we can fix the link in the directory.</p>
<h2>What about a VPN?</h2>
<p>Some people ask about using a VPN to get around regional restrictions. Here we draw attention to two things: first, that ordinary listening does not need a VPN and most stations work without one; second, that using such services is subject to the station’s terms and to the laws of your country of residence, and we do not advise getting around restrictions set by rights holders. If a station is blocked, choose an alternative from the directory.</p>
<h2>Time differences: how do you know what is on now?</h2>
<p>Morocco uses a time that may differ between summer and winter, and some countries observe daylight saving at other times. So the gap between you and Morocco may change during the year. Our advice:</p>
<ul><li>Search for “current time in Casablanca” to learn the actual gap that day.</li><li>Compare the station’s schedule (written in Moroccan time) with your local clock.</li><li>Note the times of your favorite programs in your own time in your phone.</li><li>Remember that live news and matches are broadcast on Moroccan time, so work out the gap before the match.</li></ul>
<h2>The best ways to listen abroad</h2>
<h3>1. Directly from the site</h3>
<p>Open the <a href="{link:home}#radios">station directory</a> in the browser and press “Listen”. You do not need to install anything, and you can save your favorites on your device.</p>
<h3>2. An app on the phone</h3>
<p>Apps allow background playback and control from the lock screen. You will find the <a href="https://play.google.com/store/apps/details?id=com.maradioazdhj.radiomoroccoandab" target="_blank" rel="noopener">Radio Maroc app on Google Play</a> for Android users. If you use an iPhone, the browser is a good option, and there are also well-known international radio apps.</p>
<h3>3. At home: TV and smart speakers</h3>
<p>Open the directory on a smart TV or send sound from your phone to a speaker by Bluetooth. It is a good way to gather the family around a Moroccan station in the evening. See our <a href="{link:smart-speaker}">smart speaker guide</a>.</p>
<h3>4. In the car</h3>
<p>Connect your phone to the car by Bluetooth, cable or Android Auto and Apple CarPlay. Make sure to choose the station before driving. To learn more, read <a href="{link:car}">how to choose a radio for your car or phone</a>.</p>
<h2>Data use while traveling</h2>
<p>If you use phone data in a country that is not your own, watch for roaming costs. An hour of listening at medium quality uses tens of megabytes, and the use can add up quickly. Use Wi-Fi whenever possible, choose lower quality when needed and watch your plan.</p>
<h2>Stations suited to the diaspora</h2>
<ul><li><strong>For news:</strong> Medi 1 Radio to follow Moroccan and Maghreb affairs.</li><li><strong>For music:</strong> Hit Radio, Chada FM and the Medi 1 music channels.</li><li><strong>For heritage:</strong> the Andalusi channel, tarab and malhun where available.</li><li><strong>For the Amazigh language:</strong> Radio Azawan and Radio Atbir, and see <a href="{link:amazigh}">Amazigh radio in Morocco</a>.</li><li><strong>For the Quran and calm:</strong> the Quran radio and the Sufi channel.</li><li><strong>For your region:</strong> your city’s or region’s station if there is one, to hear its news and dialect.</li></ul>
<p>If you live in France or elsewhere in Europe, see also our guide to <a href="{link:french-radio}">French-language radio in Morocco</a>.</p>
<h2>Radio and raising children in language and identity</h2>
<p>Many parents worry about their children’s weakness in Darija, Arabic or Amazigh. Radio is a simple tool: it puts the language in a child’s ear without pressure. Put on a Moroccan station in the car on the way to school, or in the kitchen at dinner time, and talk about what you heard. In time the child will get used to the rhythm and vocabulary. This does not replace daily conversation and reading, but it reinforces them.</p>
<h2>Practical tips</h2>
<ul><li>Save three stations to favorites so you can reach them quickly.</li><li>Prepare a fallback if a station stops, so you do not rely on just one.</li><li>Use good headphones if you are at work.</li><li>Check your connection before blaming the station.</li><li>Check schedules against your local time.</li></ul>
<h2>A suggested weekly routine for a Moroccan family abroad</h2>
<ul><li><strong>Weekday mornings:</strong> a brief bulletin in Darija or French at breakfast.</li><li><strong>Weekday evenings:</strong> calm music at dinner.</li><li><strong>Saturday:</strong> a light music channel for housework and cleaning.</li><li><strong>Sunday:</strong> a talk or cultural program during family cooking.</li><li><strong>Friday:</strong> the Quran radio or the Sufi channel for a spiritual atmosphere.</li></ul>
<p>This arrangement makes radio a steady part of the family rhythm, which children get used to as they do meals.</p>
<h2>Study and work abroad</h2>
<p>If you are a student or worker far from family, radio eases loneliness and keeps you in touch with the news and the language. But do not let it distract you from study: use it during breaks or while commuting. If you need concentration, choose a calm music channel without singing.</p>
<h2>Staying safe online</h2>
<ul><li>Use an up-to-date browser and avoid sites that ask for your data to play radio.</li><li>Do not enter card numbers or passwords on any site that claims to “unlock” blocked stations.</li><li>Download apps from official stores.</li></ul>
<h2>Frequently asked questions</h2>
<details class="faq"><summary>Why does a particular station not work for me?</summary><p>The cause may be a regional restriction or the server being down. Try another station, then try again later and tell us about the problem.</p></details>
<details class="faq"><summary>Do I need an app?</summary><p>No, the browser is enough, but the app suits daily listening and background playback better.</p></details>
<details class="faq"><summary>Is listening from abroad free?</summary><p>The directory is free; you only pay for internet from your provider.</p></details>
<h2>Conclusion</h2>
<p>Moroccan radio in exile is not a luxury: it is a thread tying you to your language, your memory and your country’s news. Choose the way of listening that suits you, watch the time difference and data use, and you will find in our directory what brings Morocco closer at a tap.</p>'''))

OLD_TX['fix'] = dict(
 fr=dict(title='Pourquoi la radio se coupe ou ne marche pas ? 10 solutions pratiques',
  mt='La radio se coupe ou ne marche pas : 10 solutions | Radio Maroc',
  desc="La radio ne marche pas ou se coupe sur votre téléphone ? Les causes du problème et dix solutions simples : connexion, navigateur, forfait, batterie.",
  kw='radio ne marche pas, radio se coupe, flux radio coupé téléphone, problème écoute radio en ligne',
  body='''<p>Vous appuyez sur « Écouter » et aucun son ne sort, ou le flux marche une minute puis se coupe, ou il s'arrête quand vous verrouillez l'écran. Ce sont parmi les problèmes les plus fréquents des auditeurs de radio en ligne, et la plupart se règlent en quelques minutes si l'on sait par où commencer. La cause peut venir de votre connexion, de votre appareil, du navigateur ou du serveur de la station elle-même ; il vaut donc mieux suivre un ordre logique plutôt que deviner.</p>
<p>Dans ce guide, nous expliquons les causes les plus courantes et présentons dix solutions du plus simple au plus complexe, puis nous montrons quand le défaut vient de la station et non de vous, et que faire alors.</p>
<h2>D'abord : identifiez le type de problème</h2>
<p>Avant d'essayer les solutions, observez la nature de ce qui se passe, car elle indique la cause :</p>
<ul><li><strong>Le flux ne démarre jamais :</strong> le plus souvent un lien en panne, une coupure de connexion ou un navigateur qui n'autorise pas la lecture.</li><li><strong>Il démarre puis se coupe :</strong> connexion faible ou instable, ou réseau encombré.</li><li><strong>Il s'arrête au verrouillage de l'écran :</strong> économie d'énergie ou politique du navigateur en arrière-plan.</li><li><strong>Il marche sur une station et pas sur une autre :</strong> le problème vient du serveur de cette station.</li><li><strong>Son faible ou brouillé :</strong> la qualité du flux elle-même, les réglages du son ou les écouteurs.</li></ul>
<h2>Dix solutions pratiques</h2>
<h3>1. Essayez une autre station</h3>
<p>C'est le diagnostic le plus rapide. Si une autre station fonctionne, votre connexion est saine et le problème vient du serveur de la première station. Si aucune ne marche, le problème est de votre côté.</p>
<h3>2. Rechargez la page</h3>
<p>Appuyez sur actualiser ou fermez l'onglet et rouvrez-le. Cela suffit souvent à rétablir la connexion avec le serveur.</p>
<h3>3. Vérifiez la connexion Internet</h3>
<p>Ouvrez un autre site. S'il est lent, le problème est dans le réseau. Passez du Wi-Fi aux données mobiles, rapprochez-vous du routeur et redémarrez-le si besoin.</p>
<h3>4. Vérifiez le son</h3>
<p>Montez le volume, vérifiez que le téléphone n'est pas en mode silencieux et que les écouteurs ou le Bluetooth sont reliés à l'appareil voulu. Le son est souvent dirigé vers une enceinte Bluetooth lointaine.</p>
<h3>5. Mettez à jour le navigateur ou essayez-en un autre</h3>
<p>Certaines anciennes versions ne prennent pas en charge les formats de flux modernes. Mettez à jour le navigateur ou essayez Chrome, Firefox ou Safari selon votre appareil.</p>
<h3>6. Autorisez la lecture en arrière-plan</h3>
<p>Si le flux s'arrête au verrouillage de l'écran, ouvrez les réglages de batterie de votre téléphone et excluez le navigateur ou l'application de « l'économie d'énergie » ou de « l'optimisation de la batterie ». Sur certains appareils, vous trouverez l'option « autoriser l'activité en arrière-plan ».</p>
<h3>7. Videz le cache</h3>
<p>Dans les réglages du navigateur, effacez les données temporaires du site, puis rouvrez le guide. Attention : effacer les données du site supprime les favoris enregistrés sur votre appareil.</p>
<h3>8. Allégez la connexion</h3>
<p>Fermez les applications qui consomment Internet en arrière-plan, comme les téléchargements et la vidéo. Choisissez une qualité de flux moindre si le site le permet.</p>
<h3>9. Vérifiez votre forfait</h3>
<p>Si le forfait est épuisé ou le débit réduit, le flux se coupera. Vérifiez votre crédit Internet, et sachez qu'une longue écoute consomme environ 14 à 58 Mo par heure selon la qualité, comme nous l'avons montré dans <a href="{link:car}">comment choisir sa radio pour la voiture ou le téléphone</a>.</p>
<h3>10. Réessayez plus tard ou ouvrez le site de la station</h3>
<p>Les serveurs des stations peuvent tomber temporairement pour maintenance ou à cause de la charge aux heures de pointe. Attendez quelques minutes puis réessayez, ou ouvrez le site officiel de la station pour vérifier que le flux y fonctionne.</p>
<h2>Quand le problème vient-il de la station ?</h2>
<p>Le guide propose des liens de flux fournis par les stations, qui peuvent changer ou s'arrêter sans annonce. Le problème vient le plus souvent de la station si :</p>
<ul><li>d'autres stations fonctionnent bien et une seule échoue ;</li><li>le message « flux indisponible » s'affiche chez nous ;</li><li>le site officiel de la station ne diffuse pas non plus.</li></ul>
<p>Dans ce cas, vous n'avez rien à faire sinon attendre ou essayer une alternative. Nous vous prions de nous le signaler via la <a href="{link:contact}">page Contact</a> avec le nom de la station et ce que vous avez vu : nous vérifierons le lien, le corrigerons ou le retirerons s'il reste en panne longtemps.</p>
<h2>Les problèmes propres à la voiture</h2>
<ul><li><strong>Coupure en traversant des zones mal couvertes :</strong> prévoyez une solution de repli comme la FM.</li><li><strong>Pas de son par le Bluetooth :</strong> refaites l'association de l'appareil et vérifiez la source audio de la voiture.</li><li><strong>Décalage entre les commandes et le son :</strong> certains systèmes ajoutent un petit retard, ce qui est normal.</li></ul>
<p>N'essayez pas de régler ces problèmes en conduisant. Arrêtez la voiture dans un endroit sûr ou demandez au passager de s'en charger.</p>
<h2>Des conseils pour éviter les problèmes à l'avenir</h2>
<ul><li>Enregistrez plusieurs stations en favoris pour en changer vite en cas de besoin.</li><li>Mettez régulièrement à jour le navigateur et les applications.</li><li>Utilisez le Wi-Fi autant que possible pour une longue écoute.</li><li>Redémarrez le routeur de temps en temps.</li><li>Lisez l'article <a href="{link:listen-online}">écouter la radio marocaine en ligne gratuitement</a> pour connaître les différences entre les méthodes d'écoute.</li></ul>
<h2>Tableau rapide : symptôme, cause probable, solution</h2>
<ul><li><strong>Ni son ni chargement :</strong> lien en panne ou coupure réseau → essayez une autre station puis rechargez la page.</li><li><strong>Coupures répétées :</strong> connexion faible → rapprochez-vous du routeur ou changez de réseau.</li><li><strong>Arrêt au verrouillage de l'écran :</strong> économie d'énergie → excluez le navigateur de l'optimisation de la batterie.</li><li><strong>Son faible :</strong> réglages ou orientation du son → montez le volume et vérifiez l'appareil audio relié.</li><li><strong>Ça marche puis le silence revient après quelques minutes :</strong> expiration de la connexion → relancez et essayez une qualité moindre.</li><li><strong>Ça marche sur un appareil et pas sur un autre :</strong> navigateur ou système → mettez-les à jour ou essayez un navigateur différent.</li></ul>
<h2>Un test simple de la vitesse de connexion</h2>
<p>La radio en direct n'a pas besoin d'un gros débit mais d'une connexion stable. Pour le vérifier : ouvrez une autre page lourde ou lancez un court extrait sur un autre site, et regardez s'il se coupe aussi. Si oui, c'est votre connexion qui pose problème ; sinon, le problème vient de la station ou du navigateur.</p>
<h2>Quand nous prévenir ?</h2>
<p>Envoyez-nous votre remarque si un lien ne marche pas sur plus d'un appareil et pendant plus d'un jour. Indiquez le nom de la station, l'appareil, le navigateur et ce que vous avez vu, pour que nous le vérifiions vite.</p>
<h2>Questions fréquentes</h2>
<details class="faq"><summary>Pourquoi la radio marche-t-elle en Wi-Fi et pas en données mobiles ?</summary><p>Le réseau mobile peut être faible à votre endroit, bloquer certains services ou votre forfait peut être épuisé. Essayez de vous déplacer vers un endroit mieux couvert.</p></details>
<details class="faq"><summary>Pourquoi le son s'arrête-t-il après quelques minutes ?</summary><p>Le plus souvent à cause de l'économie d'énergie ou d'une connexion faible. Appliquez les solutions 6 et 3.</p></details>
<details class="faq"><summary>Le guide peut-il être la cause du problème ?</summary><p>Nous ne diffusons pas le son nous-mêmes : il vient des serveurs des stations. Si vous constatez un lien en panne, dites-le-nous et nous le corrigerons.</p></details>
<h2>En résumé</h2>
<p>Commencez par essayer une autre station, puis vérifiez la connexion et le son, puis le navigateur et la batterie. Si seule la station est en panne, attendez ou choisissez une alternative. La plupart des problèmes sont simples et leur solution est à votre portée.</p>'''),
 en=dict(title='Why Does Radio Cut Out or Not Work? 10 Practical Fixes',
  mt='Radio Cutting Out or Not Working: 10 Fixes | Radio Maroc',
  desc='Radio not working or cutting out on your phone? Learn the causes of the problem and ten simple fixes: connection, browser, data plan, battery and the station’s server.',
  kw='radio not working, radio cutting out, radio stream stops phone, online radio problem',
  body='''<p>You press “Listen” and no sound comes out, or the stream plays for a minute and then cuts out, or it stops when you lock your phone screen. These are among the most common problems online radio listeners face, and most are solved in minutes if you know where to start. The cause may be your connection, your device, the browser or the station’s own server, so it helps to follow a logical order instead of guessing.</p>
<p>In this guide we explain the most common causes and offer ten fixes ordered from simplest to most involved, then show when the fault lies with the station and not with you, and what to do then.</p>
<h2>First: identify the type of problem</h2>
<p>Before trying the fixes, notice the nature of what is happening, because it points to the cause:</p>
<ul><li><strong>The stream never starts:</strong> usually a broken link, a lost connection or a browser that does not allow playback.</li><li><strong>It starts then cuts out:</strong> a weak or unstable connection, or a congested network.</li><li><strong>It stops when the screen locks:</strong> battery saving or the browser’s background policy.</li><li><strong>It works on one station but not another:</strong> the problem is with that station’s server.</li><li><strong>Weak or distorted sound:</strong> the stream quality itself, the sound settings or the headphones.</li></ul>
<h2>Ten practical fixes</h2>
<h3>1. Try another station</h3>
<p>This is the fastest diagnosis. If another station works, your connection is sound and the problem is with the first station’s server. If no station works, the problem is on your side.</p>
<h3>2. Reload the page</h3>
<p>Press refresh or close the tab and open it again. That is often enough to rebuild the connection to the server.</p>
<h3>3. Check your internet connection</h3>
<p>Open any other site. If it is slow, the problem is the network. Switch between Wi-Fi and mobile data, move your device closer to the router, and restart it if needed.</p>
<h3>4. Check the sound</h3>
<p>Raise the volume, check that the phone is not on silent and that headphones or Bluetooth are connected to the device you intend. The sound is often routed to a distant Bluetooth speaker.</p>
<h3>5. Update the browser or try another</h3>
<p>Some older versions do not support modern stream formats. Update the browser, or try Chrome, Firefox or Safari depending on your device.</p>
<h3>6. Allow background playback</h3>
<p>If the stream stops when the screen locks, open your phone’s battery settings and exclude the browser or app from “battery saving” or “battery optimisation”. On some devices you will find an option “allow background activity”.</p>
<h3>7. Clear the cache</h3>
<p>From the browser settings, clear the site’s temporary data, then reopen the directory. Note that clearing site data removes the favorites saved on your device.</p>
<h3>8. Ease the load on the connection</h3>
<p>Close apps that use the internet in the background, such as downloads and video. Choose lower stream quality if the site allows it.</p>
<h3>9. Check your data plan</h3>
<p>If the plan has run out or the speed has been cut, the stream will cut out. Check your internet balance, and note that long listening uses roughly 14 to 58 MB per hour depending on quality, as we showed in <a href="{link:car}">how to choose a radio for your car or phone</a>.</p>
<h3>10. Try later or open the station’s website</h3>
<p>Stations’ servers may go down temporarily for maintenance or because of load at peak times. Wait a few minutes then try again, or open the station’s official website to check that the stream works there.</p>
<h2>When is the problem with the station?</h2>
<p>The directory shows stream links provided by the stations, which may change or stop without notice. The problem is most often with the station if:</p>
<ul><li>other stations work smoothly and only one fails;</li><li>the “stream unavailable” message appears on our side;</li><li>the station’s own official website is not streaming either.</li></ul>
<p>In that case you need do nothing but wait or try an alternative. Please tell us through the <a href="{link:contact}">Contact page</a> with the station name and what you saw: we will check the link and fix it, or remove it if it stays down for a long time.</p>
<h2>Problems specific to the car</h2>
<ul><li><strong>Cut-outs when passing through weak-coverage areas:</strong> prepare a fallback such as FM.</li><li><strong>No sound over Bluetooth:</strong> pair the device again and check the car’s audio source.</li><li><strong>Delay between commands and sound:</strong> some systems add a slight delay, which is normal.</li></ul>
<p>Do not try to solve these problems while driving. Stop the car in a safe place or ask the passenger to take care of it.</p>
<h2>Tips to avoid problems in the future</h2>
<ul><li>Save more than one station to favorites so you can switch quickly when needed.</li><li>Update the browser and apps regularly.</li><li>Use Wi-Fi as much as possible for long listening.</li><li>Restart the router from time to time.</li><li>Read the article <a href="{link:listen-online}">how to listen to Moroccan radio online for free</a> to learn the differences between ways of listening.</li></ul>
<h2>Quick table: symptom, likely cause, fix</h2>
<ul><li><strong>No sound and no loading:</strong> broken link or network loss → try another station then reload the page.</li><li><strong>Repeated cut-outs:</strong> weak connection → move closer to the router or switch network.</li><li><strong>Stops when the screen locks:</strong> battery saving → exclude the browser from battery optimisation.</li><li><strong>Weak sound:</strong> sound settings or routing → raise the volume and check the connected audio device.</li><li><strong>Works then goes silent after a few minutes:</strong> connection timeout → restart and try lower quality.</li><li><strong>Works on one device but not another:</strong> browser or system → update them or try a different browser.</li></ul>
<h2>A simple connection speed test</h2>
<p>Live radio does not need high speed but a steady connection. To test: open another heavy page, or play a short clip on another site, and see whether it cuts out too. If it does, your connection is the problem; if not, the problem is the station or the browser.</p>
<h2>When should you tell us?</h2>
<p>Send us your note if you find that a link does not work on more than one device and for more than one day. State the station name, device, browser and what you saw, so we can check it quickly.</p>
<h2>Frequently asked questions</h2>
<details class="faq"><summary>Why does radio work on Wi-Fi but not on mobile data?</summary><p>The mobile network may be weak where you are, block some services, or your plan may have run out. Try moving to a place with better coverage.</p></details>
<details class="faq"><summary>Why does the sound stop after a few minutes?</summary><p>Most often because of battery saving or a weak connection. Apply fixes 6 and 3.</p></details>
<details class="faq"><summary>Could the directory be the cause of the problem?</summary><p>We do not broadcast the sound ourselves: it comes from the stations’ servers. If you notice a broken link, tell us and we will fix it.</p></details>
<h2>Conclusion</h2>
<p>Start by trying another station, then check the connection and sound, then the browser and battery. If only the station is down, wait or choose an alternative. Most problems are simple and their fix is within your reach.</p>'''))
