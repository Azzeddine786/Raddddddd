# -*- coding: utf-8 -*-
"""Radio Maroc site generator.
Usage:  python3 tools/build.py [SRC_DIR] [OUT_DIR]
Reads the existing Arabic site (SRC), writes the trilingual site (OUT):
 - Arabic stays at the root, French in /fr/, English in /en/
 - station pages, guides, hubs, home pages, static pages, sitemap, feed, manifest
Edit data/frequencies.json (verified FM numbers) and re-run to refresh the frequency tables."""
import os, re, sys, json, html, shutil
from urllib.parse import quote
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from i18n_data import *
from content_stations import STATIONS
from content_guides import GUIDES
from content_legal import LEGAL, EMAIL
from content_old_a import OLD_TX as _A
from content_old_b import OLD_TX as _B
from content_old_c import OLD_TX as _C
from content_old_d import OLD_TX as _D
from content_old_e import OLD_TX as _E
OLD_TX = {}
for _m in (_A, _B, _C, _D, _E): OLD_TX.update(_m)

SRC = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/site/Raddddddd-main'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/out/radiomaroc-site'
TODAY = '2026-11-20'
import hashlib
def _file_text(pth):
    try: return open(pth, encoding='utf8').read()
    except Exception: return ''
# cache-busting version = hash of everything that shapes style.css / app.js, so a changed file always gets a new URL
CSSV = '?v=' + hashlib.sha1((_file_text(__file__) + _file_text(os.path.join(HERE, 'app_src.js')) + _file_text(os.path.join(SRC, 'style.css'))).encode('utf8')).hexdigest()[:10]
PLAY_URL = 'https://play.google.com/store/apps/details?id=com.maradioazdhj.radiomoroccoandab'

def rd(p): return open(p, encoding='utf8').read()
def wr(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w', encoding='utf8').write(s)
def esc(s): return html.escape(s, quote=True)
def fmt(s, **kw):
    for k, v in kw.items(): s = s.replace('{' + k + '}', v)
    return s

# ------------------------------------------------------------------ copy source
if os.path.exists(OUT): shutil.rmtree(OUT)
shutil.copytree(SRC, OUT)

# ------------------------------------------------------------------ stations
ar_index = rd(os.path.join(SRC, 'index.html'))
raw = re.search(r'id="stations-data"[^>]*>(.*?)</script>', ar_index, re.S).group(1).strip()
sdata = json.JSONDecoder().raw_decode(raw)[0]
cards = re.findall(r'<article class="station" data-id="(\d+)" data-cat="([^"]*)" data-lang="([^"]*)".*?<p class="meta">([^<]*)</p>', ar_index, re.S)
meta = {int(i): (c, l, m) for i, c, l, m in cards}
STN = {}
for s in sdata:
    c, l, m = meta[s['id']]
    STN[s['id']] = dict(id=s['id'], name=s['name'], init=s['init'], stream=s['stream'], logo=s.get('logo', ''),
                        cat=html.unescape(c), lang=html.unescape(l), city=html.unescape(m.split(' • ')[0]))
N_ST = len(STN)
ST_KEY = {v['id']: k for k, v in STATIONS.items()}

def sname(lang, sid):
    if lang == 'ar': return AR_NAME.get(sid, STN[sid]['name'])
    if lang == 'fr': return FR_NAME.get(sid, STN[sid]['name'])
    return EN_NAME.get(sid, STN[sid]['name'])

def join_and(lang, items):
    w = {'ar': ' و', 'fr': ' et ', 'en': ' and '}[lang]
    if len(items) <= 1: return ''.join(items)
    return ', '.join(items[:-1]) + w + items[-1] if lang != 'ar' else '، '.join(items[:-1]) + w + items[-1]

def lang_words(lang, sid):
    return [LANGWORD.get(x.strip(), {}).get(lang, x.strip()) for x in STN[sid]['lang'].split('/')]

# ------------------------------------------------------------------ page registry
STATIC = {
 'articles': dict(ar='articles', fr='articles', en='articles'),
 'about': dict(ar='about', fr='a-propos', en='about'),
 'contact': dict(ar='contact', fr='contact', en='contact'),
 'privacy': dict(ar='privacy', fr='confidentialite', en='privacy'),
 'terms': dict(ar='terms', fr='conditions-utilisation', en='terms'),
 'disclaimer': dict(ar='disclaimer', fr='avertissement', en='disclaimer'),
 'cookies': dict(ar='cookies', fr='cookies', en='cookies'),
}
AR_ONLY_KEYS = {'fix': 'radio-stream-not-working-fixes', 'car': 'choose-radio-car-phone-morocco', 'abroad': 'listen-moroccan-radio-abroad',
                'music': 'moroccan-music-on-radio', 'news': 'best-moroccan-news-radio', 'sports': 'sports-radio-morocco',
                'regional': 'regional-moroccan-radio-guide', 'ramadan': 'ramadan-radio-morocco', 'best': 'best-moroccan-radio-stations-2026',
                'history': 'history-of-moroccan-radio', 'amazigh': 'amazigh-radio-morocco'}

_FR_SLUG = dict(best='meilleures-radios-marocaines-2026', news='meilleures-radios-information-maroc', car='choisir-radio-voiture-telephone-maroc',
    history='histoire-radio-marocaine', regional='radios-regionales-marocaines-guide', music='musique-marocaine-a-la-radio', sports='radio-sportive-maroc',
    ramadan='radio-ramadan-maroc', amazigh='radio-amazighe-maroc', abroad='ecouter-radios-marocaines-etranger', fix='radio-qui-se-coupe-solutions')
_READ = dict(best=7, news=5, car=7, history=7, regional=7, music=4, sports=4, ramadan=5, amazigh=5, abroad=5, fix=5)
OLD = {}
for _k, _slug in AR_ONLY_KEYS.items():
    OLD[_k] = dict(slug=dict(ar=_slug, fr=_FR_SLUG[_k], en=_slug), img=AR_ONLY[_slug][0], pill=AR_ONLY[_slug][1], read=_READ[_k])

def url(key, lang):
    if key == 'home': return PREFIX[lang] + '/'
    if key in STATIC: return PREFIX[lang] + '/' + STATIC[key][lang]
    if key in GUIDES: return PREFIX[lang] + '/' + GUIDES[key]['slug'][lang]
    if key in STATIONS: return PREFIX[lang] + '/' + STATIONS[key]['slug'][lang]
    if key in OLD: return PREFIX[lang] + '/' + OLD[key]['slug'][lang]
    raise KeyError(key)

def abs_url(path): return SITE + path

def resolve(text, lang):
    def rep(m): return url(m.group(1), lang)
    text = re.sub(r'\{link:([a-z0-9\-]+)\}', rep, text)
    for tok, key in [('medi1ch', 'medi1-channels'), ('mrktng', 'marrakech-tangier'), ('frradio', 'french-radio'),
                     ('sports', 'sports'), ('news', 'news'), ('music', 'music'), ('ramadan', 'ramadan'), ('regional', 'regional')]:
        text = text.replace('{' + tok + '}', url(key, lang))
    for k in STATIC:
        text = text.replace('{' + k + '}', url(k, lang))
    text = text.replace('{email}', EMAIL)
    if lang != 'ar':
        text = re.sub(r'\s*\((?:en arabe|in Arabic|guide en arabe|guide in Arabic)\)', '', text)
    return text

# ------------------------------------------------------------------ frequencies
FREQ_PATH = os.path.join(os.path.dirname(HERE), 'data', 'frequencies.json')
if not os.path.exists(FREQ_PATH): FREQ_PATH = os.path.join(SRC, 'data', 'frequencies.json')
FREQ = {'entries': []}
if os.path.exists(FREQ_PATH):
    try: FREQ = json.load(open(FREQ_PATH, encoding='utf8'))
    except Exception: pass

def freq_html(lang, sid=None):
    u = UI[lang]
    rows = [e for e in FREQ.get('entries', []) if e.get('mhz') and (sid is None or e.get('station') == sid)]
    if not rows:
        return '<div class="note-box">' + u['freq_none'] + '</div>'
    out = ['<table class="freq"><thead><tr>']
    if sid is None: out.append('<th>' + {'ar': 'المحطة', 'fr': 'Station', 'en': 'Station'}[lang] + '</th>')
    out.append('<th>' + u['freq_city'] + '</th><th>' + u['freq_mhz'] + '</th><th>' + u['freq_verified'] + '</th></tr></thead><tbody>')
    for e in rows:
        out.append('<tr>')
        if sid is None: out.append('<td>' + esc(sname(lang, e['station'])) + '</td>')
        city = CITY.get(e.get('city', ''), {}).get(lang, e.get('city', ''))
        out.append('<td>' + esc(city) + '</td><td dir="ltr">' + esc(str(e['mhz'])) + '</td><td dir="ltr">' + esc(e.get('verified', FREQ.get('last_verified', ''))) + '</td></tr>')
    out.append('</tbody></table>')
    return ''.join(out)

# ------------------------------------------------------------------ station lists
def stlist(flt, lang):
    u = UI[lang]
    kind, _, val = flt.partition(':')
    ids = []
    for sid, s in STN.items():
        if kind == 'prefix' and s['name'].startswith(val): ids.append(sid)
        elif kind == 'city' and s['city'] in val.split('|'): ids.append(sid)
        elif kind == 'lang' and val in s['lang'] and s['city'] in MOROCCAN_CITIES: ids.append(sid)
    if kind == 'ids': ids = [int(x) for x in val.split(',')]
    return stlist_ids(ids, lang)

def stlist_ids(ids, lang):
    u = UI[lang]
    out = ['<ul class="stn-list">']
    for sid in ids:
        s = STN[sid]
        n = esc(sname(lang, sid))
        link = url(ST_KEY[sid], lang) if sid in ST_KEY else None
        nm = '<a href="' + link + '">' + n + '</a>' if link else n
        cat = CAT.get(s['cat'], {}).get(lang, s['cat'])
        city = CITY.get(s['city'], {}).get(lang, s['city'])
        meta_ = ' · '.join([city, cat, join_and(lang, lang_words(lang, sid))]) if lang != 'ar' else ' · '.join([city, cat, '، '.join(lang_words(lang, sid))])
        out.append('<li><div class="sl-main"><b>' + nm + '</b><span class="sl-meta">' + esc(meta_) + '</span></div>'
                   '<button class="btn btn-red btn-sm" type="button" data-play="' + str(sid) + '" aria-label="' + esc(fmt(u['listen_to'], name=sname(lang, sid))) + '">▶ ' + u['listen'] + '</button></li>')
    out.append('</ul>')
    return ''.join(out)

def expand(body, lang):
    body = re.sub(r'\{\{STLIST:([^}]+)\}\}', lambda m: stlist(m.group(1), lang), body)
    body = body.replace('{{FREQ}}', freq_html(lang))
    return resolve(body, lang)

# ------------------------------------------------------------------ shared shell pieces
def grab(pat, s):
    m = re.search(pat, s, re.S)
    return m.group(0) if m else ''
GTM_HEAD = grab(r'<!-- ============ Google Tag Manager ============ -->.*?<!-- ============ End Google Tag Manager ============ -->', ar_index)
GA_HEAD = grab(r'<!-- ============ Google Analytics ============ -->.*?<!-- ============ End Google Analytics ============ -->', ar_index)
GTM_NS = grab(r'<!-- ============ Google Tag Manager \(noscript\) ============ -->.*?<!-- ============ End Google Tag Manager \(noscript\) ============ -->', ar_index)
ADSENSE_ID = 'ca-pub-6369463662612526'
ADSENSE_META = '<meta name="google-adsense-account" content="%s">\n' % ADSENSE_ID
ADSENSE_SCRIPT = '<script async src="https://pagead2googlesyndication.com/pagead/js/adsbygoogle.js?client=%s" crossorigin="anonymous"></script>\n' % ADSENSE_ID
# Only Google AdSense is used. The former third-party ad-network code (js.wpadmngr.com banner + sw.wpushorg.com push worker) was removed.
def ad(key, lang):
    slot = str((ADS_CFG.get('slots') or {}).get(key, '')).strip()
    if not slot: return ''
    return ('<aside class="adslot" aria-label="%s"><span class="adlabel">%s</span><ins class="adsbygoogle" style="display:block" data-ad-client="%s" data-ad-slot="%s" data-ad-format="auto" data-full-width-responsive="true"></ins>'
            '<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></aside>\n') % (AD_LABEL[lang], AD_LABEL[lang], ADSENSE_ID, esc(slot))
PRIV_OPTS = {'ar': 'إعدادات الخصوصية', 'fr': 'Paramètres de confidentialité', 'en': 'Privacy settings'}
EXTRA = {
 'ar': dict(b_title='راديو المغرب', b_sub='مجاني على Google Play', b_btn='تثبيت', b_aria='تطبيق راديو المغرب لنظام Android', close='إغلاق',
            pm_install='تثبيت من Google Play', pm_chips=['مجاني', 'Android', 'بث مباشر'], pm_about='عن التطبيق',
            pm_desc='استماع مباشر أسرع وواجهة مصممة للهاتف، مجاناً على Google Play.', pm_points=['استمع إلى الإذاعات المغربية مباشرة', 'واجهة مصممة للهاتف', 'مجاني'],
            recent='استمعت إليها مؤخراً', vol='مستوى الصوت', pm_dl='تنزيل'),
 'fr': dict(b_title='Radio Maroc', b_sub='Gratuite sur Google Play', b_btn='Installer', b_aria='Application Radio Maroc pour Android', close='Fermer',
            pm_install='Installer depuis Google Play', pm_chips=['Gratuit', 'Android', 'En direct'], pm_about="À propos de l'application",
            pm_desc="Écoute directe plus rapide, interface pensée pour le mobile, gratuite sur Google Play.", pm_points=['Écoutez les radios marocaines en direct', 'Interface pensée pour le mobile', 'Gratuit'],
            recent='Écoutées récemment', vol='Volume', pm_dl='Télécharger'),
 'en': dict(b_title='Radio Maroc', b_sub='Free on Google Play', b_btn='Install', b_aria='Radio Maroc app for Android', close='Close',
            pm_install='Install from Google Play', pm_chips=['Free', 'Android', 'Live radio'], pm_about='About this app',
            pm_desc='Faster live listening and an interface designed for mobile, free on Google Play.', pm_points=['Listen to Moroccan radio live', 'An interface designed for mobile', 'Free'],
            recent='Recently played', vol='Volume', pm_dl='Download'),
}
def load_cfg(name, default):
    for pth in (os.path.join(os.path.dirname(HERE), 'data', name), os.path.join(SRC, 'data', name)):
        if os.path.exists(pth):
            try: return json.load(open(pth, encoding='utf8'))
            except Exception: pass
    return default
PLAY_CFG = load_cfg('play.json', {})
ADS_CFG = load_cfg('adsense.json', {})
AD_LABEL = {'ar': 'إعلان', 'fr': 'Publicité', 'en': 'Advertisement'}

NP_CFG = load_cfg('nowplaying.json', {})
_PLAY_SRC = os.path.join(os.path.dirname(HERE), 'play')
if os.path.isdir(_PLAY_SRC) and os.path.abspath(_PLAY_SRC) != os.path.abspath(os.path.join(OUT, 'play')):
    shutil.copytree(_PLAY_SRC, os.path.join(OUT, 'play'), dirs_exist_ok=True)

def alt_links(alts):
    if not alts: return ''
    out = ''.join('<link rel="alternate" hreflang="%s" href="%s">' % (l, abs_url(p)) for l, p in alts.items())
    return out + '<link rel="alternate" hreflang="x-default" href="%s">' % abs_url(alts.get('en', list(alts.values())[0]))

REDIRECT_JS = '''<script>(function(){try{var p=location.pathname;if(p!=='/'&&p!=='/index.html')return;
if(/bot|crawl|spider|slurp|bing|google|yandex|baidu|duckduck|facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegram|lighthouse|pagespeed|headless|preview/i.test(navigator.userAgent)||navigator.webdriver)return;
var S=['ar','fr','en'],t=null,pref=null;try{pref=localStorage.getItem('rm_lang')}catch(e){}
if(pref&&S.indexOf(pref)>-1){t=pref}else{var L=navigator.languages&&navigator.languages.length?navigator.languages:[navigator.language||'en'];
for(var i=0;i<L.length;i++){var c=String(L[i]).toLowerCase().split('-')[0];if(S.indexOf(c)>-1){t=c;break}}if(!t)t='en'}
if(t!=='ar')location.replace('/'+t+'/'+location.search+location.hash)}catch(e){}})();</script>
'''

CRIT_CSS = ('<style id="crit-banner">.appbanner{background:linear-gradient(90deg,#272225,#3d2c31);color:#fff6ed;position:relative;z-index:45;border-bottom:1px solid #00000040}'
 'html.no-appbanner .appbanner{display:none}.appbanner-in{display:flex;align-items:center;gap:10px;min-height:62px;padding-block:8px;max-width:1240px;margin-inline:auto;padding-inline:16px}'
 '.appbanner .x{background:none;border:0;color:#cdb9ad;font-size:24px;line-height:1;cursor:pointer;padding:6px 8px;border-radius:8px}'
 '.appbanner .open{display:flex;align-items:center;gap:12px;flex:1;min-width:0;background:none;border:0;color:inherit;cursor:pointer;text-align:start;padding:0;font:inherit}'
 '.appbanner .ico{width:46px;height:46px;border-radius:12px;overflow:hidden;flex-shrink:0;box-shadow:0 3px 10px #0006;background:#fff;display:block}.appbanner .ico img{width:100%;height:100%;display:block}'
 '.appbanner .txt{min-width:0;line-height:1.35}.appbanner .txt b{display:block;font-size:14.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
 '.appbanner .txt small{display:block;font-size:12px;color:#e2cfc2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
 '.appbanner .get{background:#01875f;color:#fff;font:800 13.5px inherit;border:0;border-radius:22px;padding:9px 20px;cursor:pointer;flex-shrink:0}'
 '.pm{display:none}</style>\n')

def head(lang, title, desc, path, image, og_type, alts, jsonld, home=False, extra='', early=''):
    u = UI[lang]
    img = abs_url('/' + image)
    canon = abs_url(path)
    parts = ['<!DOCTYPE html>\n<html lang="%s" dir="%s">\n<head>\n' % (HTML_LANG[lang], DIR[lang])]
    if home: parts.append(GTM_HEAD + '\n')
    parts.append('<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n' + ADSENSE_META + early)
    parts.append('<title>%s</title>\n<meta name="description" content="%s">\n<link rel="canonical" href="%s">\n' % (esc(title), esc(desc), canon))
    parts.append(alt_links(alts) + '\n')
    parts.append('<meta name="robots" content="index,follow,max-image-preview:large">\n<meta name="theme-color" content="#b63539">\n')
    parts.append('<link rel="icon" href="/favicon.svg" type="image/svg+xml">\n<link rel="icon" href="/icon-192.png" sizes="192x192" type="image/png">\n<link rel="apple-touch-icon" href="/apple-touch-icon.png">\n')
    parts.append('<meta property="og:site_name" content="%s">\n<meta property="og:locale" content="%s">\n<meta property="og:type" content="%s">\n' % (esc(u['brand_plain']), OG_LOCALE[lang], og_type))
    parts.append('<meta property="og:title" content="%s">\n<meta property="og:description" content="%s">\n<meta property="og:url" content="%s">\n<meta property="og:image" content="%s">\n' % (esc(title), esc(desc), canon, img))
    parts.append('<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n<meta property="og:image:alt" content="%s">\n' % esc(u['brand_plain'] + ' - ' + u['dir_title']))
    for l in LANGS:
        if l != lang and alts and l in alts: parts.append('<meta property="og:locale:alternate" content="%s">\n' % OG_LOCALE[l])
    if og_type == 'article':
        parts.append('<meta property="article:published_time" content="%sT08:00:00+01:00">\n<meta property="article:modified_time" content="%sT08:00:00+01:00">\n' % (TODAY, TODAY))
    parts.append('<meta name="twitter:card" content="summary_large_image">\n<meta name="twitter:title" content="%s">\n<meta name="twitter:description" content="%s">\n<meta name="twitter:image" content="%s">\n' % (esc(title), esc(desc), img))
    parts.append('<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n')
    font = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&amp;display=swap'
    parts.append('<link rel="preload" as="style" href="%s" onload="this.onload=null;this.rel=\'stylesheet\'">\n<noscript><link rel="stylesheet" href="%s"></noscript>\n' % (font, font))
    parts.append(CRIT_CSS)
    parts.append('<link rel="manifest" href="/manifest.webmanifest">\n<link rel="alternate" type="application/rss+xml" title="%s" href="/feed.xml">\n<link rel="stylesheet" href="/style.css%s">\n' % (esc(u['brand_plain']), CSSV))
    parts.append(ADSENSE_SCRIPT)
    for j in jsonld:
        parts.append('<script type="application/ld+json">' + json.dumps(j, ensure_ascii=False, separators=(',', ':')) + '</script>\n')
    if home: parts.append(GA_HEAD + '\n')
    parts.append(extra + '</head>\n')
    return ''.join(parts)

def lang_switcher(lang, alts):
    out = ['<div class="langsw" role="group" aria-label="%s">' % esc(UI[lang]['lang_label'])]
    for l in LANGS:
        href = alts.get(l, PREFIX[l] + '/') if alts else PREFIX[l] + '/'
        cur = ' aria-current="true"' if l == lang else ''
        out.append('<a href="%s" hreflang="%s" lang="%s" title="%s"%s>%s</a>' % (href, l, l, LANG_NAME[l], cur, l.upper()))
    out.append('</div>')
    return ''.join(out)

def header(lang, alts, current=''):
    u = UI[lang]
    home = url('home', lang)
    def a(href, label, key):
        cur = ' aria-current="page"' if current == key else ''
        return '<a href="%s"%s>%s</a>' % (href, cur, label)
    nav = a(home + '#radios', u['stations'], 'home') + a(url('articles', lang), u['articles'], 'articles') + a(url('about', lang), u['about'], 'about') + a(url('contact', lang), u['contact'], 'contact')
    brand_sub = '<span class="brand-sub">%s</span>' % u['brand_sub']
    return ('<a class="skip" href="#main">%s</a>\n<header class="top"><div class="wrap top-inner">\n'
            '<a class="brand" href="%s" aria-label="%s"><img src="/app-icon-96.png" alt="" width="44" height="44"><span><span class="brand-name">%s</span>%s</span></a>\n'
            '<nav class="nav" id="mainNav" aria-label="%s">%s</nav>\n'
            '<div class="tools"><time class="clock" id="clock" aria-hidden="true"></time>%s<button class="menu-btn" id="menuBtn" type="button" aria-expanded="false" aria-controls="mainNav">%s</button></div>\n'
            '</div></header>\n') % (u['skip'], home, esc(u['brand_plain'] + ' - ' + u['home']), u['brand_html'], brand_sub, u['nav_label'], nav, lang_switcher(lang, alts), u['menu'])

def footer(lang):
    u = UI[lang]
    links = ''.join('<a href="%s">%s</a>' % (url(k, lang) if k != 'home' else url('home', lang) + '#radios', u[l]) for k, l in
                    [('home', 'stations'), ('articles', 'articles'), ('about', 'about'), ('contact', 'contact'), ('privacy', 'privacy'), ('terms', 'terms'), ('disclaimer', 'disclaimer'), ('cookies', 'cookies')])
    links += '<a href="%s" data-privacy-opts>%s</a>' % (url('privacy', lang), PRIV_OPTS[lang])
    st = ''.join('<a href="%s">%s</a>' % (url(k, lang), esc(sname(lang, v['id']))) for k, v in STATIONS.items())
    langs = ''.join('<a href="%s" hreflang="%s" lang="%s">%s</a>' % (PREFIX[l] + '/', l, l, LANG_NAME[l]) for l in LANGS)
    return ('<footer class="foot"><div class="wrap">\n<div class="foot-in">\n<div><b>%s</b><p>%s</p></div>\n<nav class="foot-links" aria-label="%s">%s</nav>\n</div>\n'
            '<div class="foot-links" style="margin-top:14px"><b>%s:</b>%s</div>\n<div class="foot-links" style="margin-top:10px">%s</div>\n<div class="copy">%s</div>\n</div></footer>\n') % (
            u['brand_plain'], u['foot_tag'], u['footer_links'], links, u['foot_stations'], st, langs, u['copy'])

def app_banner(lang):
    x = EXTRA[lang]
    return ('<div class="appbanner" role="region" aria-label="%s"><script>(function(){try{var d=document.documentElement;if(/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1)||+localStorage.getItem("rm_appbanner")>Date.now())d.classList.add("no-appbanner")}catch(e){}})();</script>'
            '<div class="wrap appbanner-in"><button class="x" type="button" data-close-banner aria-label="%s">&times;</button>'
            '<button class="open" type="button" data-open-play><span class="ico"><img src="/app-icon.png" alt="" width="44" height="44"></span><span class="txt"><b>%s</b><small>%s</small></span></button>'
            '<button class="get" type="button" data-open-play>%s</button></div></div>\n') % (esc(x['b_aria']), esc(x['close']), esc(x['b_title']), esc(x['b_sub']), esc(x['b_btn']))

def play_modal(lang):
    x = EXTRA[lang]
    name = esc(PLAY_CFG.get('name') or x['b_title'])
    dev = ('<div class="pm-dev">%s</div>' % esc(PLAY_CFG['developer'])) if PLAY_CFG.get('developer') else ''
    chips = []
    if PLAY_CFG.get('rating'): chips.append('%s &#9733;' % esc(str(PLAY_CFG['rating'])))
    if PLAY_CFG.get('downloads'): chips.append(esc(str(PLAY_CFG['downloads'])))
    chips += [esc(c) for c in x['pm_chips']]
    meta = ''.join('<div><b>%s</b></div>' % c for c in chips[:4])
    shots = [p_ for p_ in PLAY_CFG.get('screenshots', []) if os.path.exists(os.path.join(OUT, p_.lstrip('/')))]
    shots_html = ('<div class="pm-shots" aria-hidden="true">%s</div>' % ''.join('<img src="%s" alt="" loading="lazy" height="260">' % esc(p_) for p_ in shots)) if shots else ''
    desc = esc(PLAY_CFG.get('description') or x['pm_desc'])
    pts = ''.join('<li>%s</li>' % esc(t) for t in x['pm_points'])
    return ('<div class="pm" id="playModal" role="dialog" aria-modal="true" aria-hidden="true" aria-label="%s" data-auto="1" data-delay="8000"><div class="pm-card">'
            '<button class="pm-x" type="button" data-close-play aria-label="%s">&times;</button>'
            '<div class="pm-top"><svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#01875f" d="M4 3.5v17a1 1 0 001.5.9l15-8.5a1 1 0 000-1.8l-15-8.5A1 1 0 004 3.5z"/></svg><span>Google Play</span></div>'
            '<div class="pm-head"><img class="pm-ico" src="/app-icon.png" alt="" width="84" height="84"><div><h2 class="pm-title">%s</h2>%s<div class="pm-sub">%s</div></div></div>'
            '<div class="pm-meta">%s</div>'
            '<a class="pm-install" href="%s" target="_blank" rel="noopener">%s</a>%s'
            '<div class="pm-about"><h3>%s</h3><p>%s</p><ul>%s</ul></div></div></div>\n') % (
            esc(x['b_aria']), esc(x['close']), name, dev, esc(x['b_sub']), meta, PLAY_URL, esc(x['pm_install']), shots_html, esc(x['pm_about']), desc, pts)

def player_block(lang):
    u = UI[lang]; x = EXTRA[lang]
    eq = '<span class="eq" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'
    return ('<div class="player" id="playerBar" role="region" aria-label="%s"><div class="wrap player-in"><div class="logo" id="pLogo">RM</div><div class="pid"><b id="pName">%s</b>'
            '<div class="ptrack" id="pTrack"></div>'
            '<div class="pstat"><span class="dot" id="pDot" style="background:#777"></span><span id="pStatus" aria-live="polite">%s</span>%s</div></div>'
            '<input class="vol" id="volRange" type="range" min="0" max="100" value="100" aria-label="%s">'
            '<button class="pbtn" id="playBtn" type="button" aria-label="%s"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button>'
            '<button class="pstop" id="stopBtn" type="button" aria-label="%s"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div></div>\n') % (
            u['player_aria'], u['p_choose'], u['p_ready'], eq, esc(x['vol']), u['p_toggle'], u['p_close'])

def st_sub(lang, sid):
    s_ = STN[sid]
    city = CITY.get(s_['city'], {}).get(lang, s_['city']); cat = CAT.get(s_['cat'], {}).get(lang, s_['cat'])
    return ' · '.join([city, cat, ' / '.join(lang_words(lang, sid))])

def player_assets(lang, home=False):
    return player_block(lang) + '<script type="application/json" id="stations-data">' + json.dumps(
        [dict(id=v['id'], name=(sname(lang, v['id']) if (v['id'] in ST_KEY and not home) else v['name']), init=v['init'], stream=v['stream'], logo=v['logo'], sub=st_sub(lang, v['id'])) for v in STN.values()],
        ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/') + '</script>\n<script>window.RM_NP=' + json.dumps(NP_CFG.get('stations', {}), ensure_ascii=False) + ';</script>\n'

def i18n_script(lang):
    i18n = dict(UI[lang]['js']); i18n['brand'] = UI[lang]['brand_plain']
    return '<script>window.RM_LANG="%s";window.RM_I18N=%s;</script>\n' % (lang, json.dumps(i18n, ensure_ascii=False))

def tail(lang, with_player=True, home=False):
    u = UI[lang]
    i18n = dict(u['js']); i18n['brand'] = u['brand_plain']
    cookie = ('<div class="cookie" id="cookieBar" role="dialog" aria-label="%s"><p>%s</p><button id="cookieOk" type="button">%s</button></div>\n') % (
        u['cookie_aria'], fmt(u['cookie_msg'], cookies=url('cookies', lang), privacy=url('privacy', lang)), u['cookie_ok'])
    s = ''
    if with_player: s += player_assets(lang, home)
    s += play_modal(lang)
    s += cookie + '<div class="toast" id="toast" role="status" aria-live="polite"></div>\n'
    s += '<script>window.RM_LANG="%s";window.RM_I18N=%s;</script>\n' % (lang, json.dumps(i18n, ensure_ascii=False))
    s += '<script src="/app.js%s" defer></script>\n' % CSSV
    return s + '</body>\n</html>\n'

def body_open(home=False, lang='ar'):
    return '<body>\n' + (GTM_NS + '\n' if home else '') + app_banner(lang)

def fmt_date(lang, d=TODAY):
    y, m, dd = d.split('-'); mi = int(m) - 1; dd = str(int(dd))
    M = {'ar': ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نونبر', 'دجنبر'],
         'fr': ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'],
         'en': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']}
    if lang == 'en': return '%s %s, %s' % (M['en'][mi], dd, y)
    return '%s %s %s' % (dd, M[lang][mi], y)

# ------------------------------------------------------------------ metadata of all new pages (two-pass)
ART_OG = {'art-online.svg': 'og-listen-radio-online-morocco.jpg', 'art-music.svg': 'og-moroccan-music-on-radio.jpg',
          'art-regional.svg': 'og-regional-moroccan-radio-guide.jpg', 'art-car.svg': 'og-choose-radio-car-phone-morocco.jpg',
          'art-stations.svg': 'og-home.jpg'}
META = {l: {} for l in LANGS}

def station_texts(lang, key):
    st = STATIONS[key]; sid = st['id']; s = STN[sid]
    n = sname(lang, sid)
    cat = CAT.get(s['cat'], {}).get(lang, s['cat'])
    city = CITY.get(s['city'], {}).get(lang, s['city'])
    langs = join_and(lang, lang_words(lang, sid))
    if lang == 'ar':
        return st['ar_h1'], st['ar_mt'], st['ar_md']
    if lang == 'fr':
        mt = n + ' en direct : fréquence et programmes | Radio Maroc'
        if len(mt) > 65: mt = n + ' en direct | Radio Maroc'
        return (n + ' en direct : fréquence, programmes et écoute gratuite', mt,
                'Écoutez %s en direct : station %s basée à %s, en %s. Fréquence FM, programmes et écoute gratuite sur mobile.' % (n, cat.lower(), city, langs))
    return (n + ' Live: Listen Online, FM Frequency and Programs', n + ' live: frequency and programs | Radio Maroc',
            'Listen to %s live: a %s station based in %s broadcasting in %s. FM frequency info, programs and free online listening.' % (n, cat.lower(), city, langs))

for lang in LANGS:
    for key, g in GUIDES.items():
        t = g[lang]
        META[lang][key] = dict(title=t['title'], mt=t['mt'], desc=t['desc'], img=g['img'], pill=g['pill'], kind='guide')
    for key in STATIONS:
        h1, mt, md = station_texts(lang, key)
        META[lang][key] = dict(title=h1, mt=mt, desc=md, img='art-stations.svg', pill='pill_station', kind='station')

for lang in ('fr', 'en'):
    for key in OLD:
        t = OLD_TX[key][lang]
        META[lang][key] = dict(title=t['title'], mt=t['mt'], desc=t['desc'], img=OLD[key]['img'], pill=OLD[key]['pill'], kind='old')
for key, slug in AR_ONLY_KEYS.items():
    _h = rd(os.path.join(SRC, slug + '.html'))
    _t = html.unescape(re.search(r'<h1[^>]*>(.*?)</h1>', _h, re.S).group(1))
    _d = html.unescape(re.search(r'<meta name="description" content="(.*?)">', _h).group(1))
    META['ar'][key] = dict(title=_t, mt=_t, desc=_d, img=OLD[key]['img'], pill=OLD[key]['pill'], kind='old')

def card(lang, key, eager=False):
    m = META[lang][key]; u = UI[lang]
    return ('<a class="acard" href="%s"><div class="thumb"><img src="/%s" alt="" width="1200" height="630" decoding="async" loading="lazy"></div>'
            '<div class="body"><span class="pill">%s</span><h3>%s</h3><p>%s</p><span class="more">%s</span></div></a>') % (
            url(key, lang), m['img'], u[m['pill']], esc(m['title']), esc(m['desc']), u['read_more'])

def card_ar_only(lang, akey):
    img, pill, tr = AR_ONLY[AR_ONLY_KEYS[akey]] if False else AR_ONLY[AR_ONLY_KEYS[akey]]
    t, d = tr[lang]
    u = UI[lang]
    return ('<a class="acard" href="/%s" hreflang="ar"><div class="thumb"><img src="/%s" alt="" width="1200" height="630" decoding="async" loading="lazy"></div>'
            '<div class="body"><span class="pill">%s · AR</span><h3>%s</h3><p>%s</p><span class="more">%s</span></div></a>') % (
            AR_ONLY_KEYS[akey], img, u[pill], esc(t), esc(d), u['read_more'])

# ------------------------------------------------------------------ alternates
def alts_for(key):
    if key == 'home' or key in STATIC or key in GUIDES or key in STATIONS or key in OLD:
        return {l: url(key, l) for l in LANGS}
    return None

# ------------------------------------------------------------------ article / station page rendering
REL = {'listen-online': ['smart-speaker', 'fm-frequencies', 'medi1-channels'], 'medi1-channels': ['chaabi', 'medi-1-radio', 'listen-online'],
       'fm-frequencies': ['casablanca', 'marrakech-tangier', 'listen-online'], 'french-radio': ['medi-1-radio', 'atlantic-radio', 'casablanca'],
       'casablanca': ['radio-mars', 'hit-radio-maroc', 'fm-frequencies'], 'smart-speaker': ['listen-online', 'fm-frequencies', 'medi1-channels'],
       'chaabi': ['medi1-channels', 'chada-fm', 'medina-fm'], 'marrakech-tangier': ['medina-fm', 'cap-radio', 'fm-frequencies']}
REL.update({'best': ['car', 'listen-online', 'news'], 'news': ['best', 'regional', 'sports'], 'car': ['listen-online', 'smart-speaker', 'fix'],
    'history': ['regional', 'music', 'best'], 'regional': ['history', 'amazigh', 'marrakech-tangier'], 'music': ['medi1-channels', 'amazigh', 'history'],
    'sports': ['radio-mars', 'news', 'car'], 'ramadan': ['radio-quran', 'abroad', 'listen-online'], 'amazigh': ['regional', 'music', 'abroad'],
    'abroad': ['listen-online', 'french-radio', 'amazigh'], 'fix': ['listen-online', 'car', 'smart-speaker']})
STATION_CITY_GUIDE = {'الدار البيضاء': 'casablanca', 'طنجة': 'marrakech-tangier', 'مراكش': 'marrakech-tangier', 'الرباط': 'fm-frequencies'}

def add_ids(body):
    toc = []
    def rep(m):
        i = len(toc) + 1
        toc.append((i, re.sub(r'<[^>]+>', '', m.group(1))))
        return '<h2 id="s%d">%s</h2>' % (i, m.group(1))
    body = re.sub(r'<h2>(.*?)</h2>', rep, body, flags=re.S)
    return body, toc

def faq_ld(body):
    qa = re.findall(r'<details class="faq"><summary>(.*?)</summary><p>(.*?)</p></details>', body, re.S)
    if not qa: return None
    strip = lambda s: html.unescape(re.sub(r'<[^>]+>', '', s))
    return {'@context': 'https://schema.org', '@type': 'FAQPage', 'mainEntity': [
        {'@type': 'Question', 'name': strip(q), 'acceptedAnswer': {'@type': 'Answer', 'text': strip(a)}} for q, a in qa]}

def station_body(lang, key):
    u = UI[lang]; st = STATIONS[key]; sid = st['id']; s = STN[sid]; tx = st[lang]
    n = sname(lang, sid)
    cat = CAT.get(s['cat'], {}).get(lang, s['cat'])
    city = CITY.get(s['city'], {}).get(lang, s['city'])
    langs = join_and(lang, lang_words(lang, sid))
    logo = ('<img src="%s" alt="%s" width="78" height="78" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.remove()">' % (esc(s['logo']), esc(fmt(u['logo_alt'], name=n)))) if s['logo'] else ''
    hero = ('<div class="stn-hero"><div class="stn-logo"><span>%s</span>%s</div><dl class="stn-facts"><div><dt>%s</dt><dd>%s</dd></div><div><dt>%s</dt><dd>%s</dd></div>'
            '<div><dt>%s</dt><dd>%s</dd></div><div><dt>%s</dt><dd>%s</dd></div></dl>'
            '<button class="btn btn-red" type="button" data-play="%d">%s</button></div>') % (
            esc(s['init']), logo, u['st_city'], esc(city), u['st_cat'], esc(cat), u['st_lang'], esc(langs), u['st_free'], u['st_free_v'], sid, u['listen_now'])
    fq = {
     'ar': [('كيف أستمع إلى %s مباشرة؟' % n, 'اضغط زر «استمع» في أعلى هذه الصفحة فيبدأ البث من متصفحك دون حساب أو تسجيل. وإن لم يعمل فأعد تحميل الصفحة أو راجع <a href="%s">دليل حلول انقطاع البث</a>.' % url('fix', lang)),
            ('ما تردد %s على موجة FM؟' % n, 'تختلف الترددات من مدينة إلى أخرى وقد تتغير، ولذلك لا ننشر رقماً قبل التحقق منه من مصدر رسمي. راجع الموقع الرسمي للمحطة أو <a href="%s">دليل الترددات حسب المدينة</a>. أما الاستماع عبر الإنترنت فلا يحتاج إلى تردد.' % url('fm-frequencies', lang)),
            ('بأي لغة تبث %s؟' % n, '%s محطة مقرها %s وتبث بـ%s، وهي مصنفة في دليلنا ضمن فئة «%s».' % (n, city, langs, cat))],
     'fr': [('Comment écouter %s en direct ?' % n, 'Appuyez sur « Écouter » en haut de cette page : le flux démarre dans votre navigateur, sans compte ni inscription. S\'il ne démarre pas, rechargez la page ou consultez le <a href="%s">guide des coupures de flux</a> (en arabe).' % url('fix', lang)),
            ('Quelle est la fréquence FM de %s ?' % n, 'Les fréquences varient d\'une ville à l\'autre et peuvent changer ; nous ne publions donc un chiffre qu\'après vérification auprès d\'une source officielle. Consultez le site officiel de la station ou notre <a href="%s">guide des fréquences par ville</a>. L\'écoute en ligne ne demande aucune fréquence.' % url('fm-frequencies', lang)),
            ('En quelles langues %s émet-elle ?' % n, '%s est une station basée à %s qui émet en %s ; notre guide la classe dans la catégorie « %s ».' % (n, city, langs, cat))],
     'en': [('How do I listen to %s live?' % n, 'Press “Listen” at the top of this page and the stream starts in your browser, with no account or sign-up. If it does not start, reload the page or see the <a href="%s">guide to stream cut-outs</a> (in Arabic).' % url('fix', lang)),
            ('What is the FM frequency of %s?' % n, 'Frequencies vary from city to city and can change, so we only publish a number once it is verified with an official source. Check the station’s official website or our <a href="%s">guide to frequencies by city</a>. Listening online needs no frequency.' % url('fm-frequencies', lang)),
            ('Which languages does %s broadcast in?' % n, '%s is a station based in %s that broadcasts in %s; our directory files it under “%s”.' % (n, city, langs, cat))]}[lang]
    faq = ''.join('<details class="faq"><summary>%s</summary><p>%s</p></details>' % (q, a) for q, a in fq)
    how = {'ar': '<ul><li><strong>من الهاتف أو الحاسوب:</strong> اضغط «استمع» أعلاه، ولا حاجة إلى حساب.</li><li><strong>في السيارة:</strong> اقرنه بالبلوتوث أو استعمل كابل AUX، أو ابحث عن التردد في مدينتك من <a href="%s">دليل الترددات</a>.</li><li><strong>من خارج المغرب:</strong> معظم المحطات تبث للعالم؛ التفاصيل في <a href="%s">دليل الاستماع أونلاين</a>.</li></ul>',
           'fr': '<ul><li><strong>Sur téléphone ou ordinateur :</strong> appuyez sur « Écouter » ci-dessus, sans compte.</li><li><strong>En voiture :</strong> associez-le en Bluetooth ou utilisez un câble AUX, ou cherchez la fréquence dans votre ville avec le <a href="%s">guide des fréquences</a>.</li><li><strong>Depuis l\'étranger :</strong> la plupart des stations diffusent dans le monde entier ; détails dans le <a href="%s">guide pour écouter en ligne</a>.</li></ul>',
           'en': '<ul><li><strong>On a phone or computer:</strong> press “Listen” above, no account needed.</li><li><strong>In the car:</strong> pair it by Bluetooth or use an AUX cable, or look up the frequency in your city in the <a href="%s">frequency guide</a>.</li><li><strong>From abroad:</strong> most stations broadcast worldwide; details in the <a href="%s">guide to listening online</a>.</li></ul>'}[lang] % (url('fm-frequencies', lang), url('listen-online', lang))
    sim = stlist_ids(st['sim'], lang)
    body = (hero + '<p>' + tx['intro'] + '</p>' + '<h2>' + u['st_h_hear'] + '</h2><p>' + tx['hear'] + '</p><p><strong>' + u['st_best'] + ':</strong> ' + tx['best'] + '</p>'
            + '<h2>' + u['st_h_freq'] + '</h2>' + freq_html(lang, sid) + '<h2>' + u['st_h_how'] + '</h2>' + how
            + '<h2>' + u['st_h_faq'] + '</h2>' + faq + '<h2>' + u['st_h_sim'] + '</h2>' + sim)
    return resolve(body, lang)

def render_page(lang, key):
    u = UI[lang]; m = META[lang][key]
    path = url(key, lang)
    is_station = m['kind'] == 'station'
    if is_station:
        raw_body = station_body(lang, key)
        read = 3
        kw = STATIONS[key]['kw'][lang] if lang in STATIONS[key]['kw'] else ''
    elif m['kind'] == 'old':
        raw_body = expand(OLD_TX[key][lang]['body'], lang)
        read = OLD[key]['read']
        kw = OLD_TX[key][lang]['kw']
    else:
        g = GUIDES[key]
        raw_body = expand(g[lang]['body'], lang)
        read = g['read']
        kw = g[lang]['kw']
    body, toc = add_ids(raw_body)
    toc_html = '<ol>' + ''.join('<li><a href="#s%d">%s</a></li>' % (i, t) for i, t in toc) + '</ol>'
    alts = alts_for(key)
    image = ART_OG.get(m['img'], 'og-home.jpg')
    if m['kind'] == 'old' and os.path.exists(os.path.join(SRC, 'og-' + OLD[key]['slug']['ar'] + '.jpg')): image = 'og-' + OLD[key]['slug']['ar'] + '.jpg'
    if m['kind'] == 'guide' and os.path.exists(os.path.join(SRC, 'og-' + GUIDES[key]['slug']['ar'] + '.jpg')): image = 'og-' + GUIDES[key]['slug']['ar'] + '.jpg'
    words = len(re.sub(r'<[^>]+>', ' ', body).split())
    org = {'@type': 'Organization', '@id': SITE + '/#org', 'name': u['brand_plain'], 'url': SITE + '/', 'logo': {'@type': 'ImageObject', 'url': SITE + '/app-icon.png', 'width': 512, 'height': 512}}
    art = {'@context': 'https://schema.org', '@type': 'Article', 'headline': m['title'], 'description': m['desc'], 'inLanguage': lang, 'datePublished': TODAY, 'dateModified': TODAY,
           'wordCount': words, 'keywords': kw, 'articleSection': u[m['pill']], 'image': [abs_url('/' + image)], 'mainEntityOfPage': {'@type': 'WebPage', '@id': abs_url(path)},
           'author': {'@type': 'Organization', 'name': u['author_b'], 'url': abs_url(url('about', lang))}, 'publisher': org, 'isPartOf': {'@id': SITE + '/#website'}}
    crumbs = {'@context': 'https://schema.org', '@type': 'BreadcrumbList', 'itemListElement': [
        {'@type': 'ListItem', 'position': 1, 'name': u['home'], 'item': abs_url(url('home', lang))},
        {'@type': 'ListItem', 'position': 2, 'name': u['articles'], 'item': abs_url(url('articles', lang))},
        {'@type': 'ListItem', 'position': 3, 'name': m['title'], 'item': abs_url(path)}]}
    ld = [art, crumbs]
    if is_station:
        sid = STATIONS[key]['id']; s = STN[sid]
        ld.append({'@context': 'https://schema.org', '@type': 'BroadcastService', 'name': sname(lang, sid), 'broadcastDisplayName': sname(lang, sid), 'description': m['desc'],
                   'inLanguage': [LANGWORD.get(x.strip(), {}).get('en', x.strip()) for x in s['lang'].split('/')], 'areaServed': 'MA', 'url': abs_url(path), 'provider': {'@id': SITE + '/#org'}})
    f = faq_ld(body)
    if f: ld.append(f)
    # related
    if is_station:
        city_guide = STATION_CITY_GUIDE.get(STN[STATIONS[key]['id']]['city'], 'fm-frequencies')
        rel_keys = [city_guide, 'fm-frequencies', 'listen-online']
        rel_keys = list(dict.fromkeys(rel_keys))[:3]
    else:
        rel_keys = REL[key]
    related = '<section class="related" aria-labelledby="rel-h"><h2 id="rel-h">%s</h2><div class="agrid">%s</div></section>' % (u['related'], ''.join(card(lang, k) for k in rel_keys))
    full = url_abs = abs_url(path)
    share = ('<div class="share"><a href="https://wa.me/?text=%s" target="_blank" rel="noopener">%s</a><a href="https://www.facebook.com/sharer/sharer.php?u=%s" target="_blank" rel="noopener">Facebook</a>'
             '<a href="https://twitter.com/intent/tweet?url=%s" target="_blank" rel="noopener">X</a><button type="button" data-copy="%s">%s</button></div>') % (
             quote(m['title'] + ' ' + full, safe=''), u['share_whatsapp'], esc(full), esc(full), esc(full), u['copy_link'])
    cta = '<div class="cta"><div><b>%s</b><span>%s</span></div><a class="btn btn-ivory" href="%s#radios">%s</a></div>' % (u['cta_b'], u['cta_s'], url('home', lang), u['cta_btn'])
    author = '<div class="authorbox"><img src="/app-icon-96.png" alt="" width="52" height="52" style="border-radius:22%%"><p><b>%s</b><br>%s</p></div>' % (u['author_b'], fmt(u['author_p'], contact=url('contact', lang), about=url('about', lang)))
    hero_img = '' if is_station else '<figure class="hero-img"><img src="/%s" alt="%s" width="1200" height="630" decoding="async" fetchpriority="high"></figure>' % (m['img'], esc(m['title']))
    mins = '%d %s' % (read, u['minutes'])
    byline = '<div class="byline"><span>%s</span><span>%s: <time datetime="%s">%s</time></span><span>%s: <time datetime="%s">%s</time></span><span>%s: %s</span></div>' % (
        u['byline_by'], u['published'], TODAY, fmt_date(lang), u['updated'], TODAY, fmt_date(lang), u['reading'], mins)
    crumb_html = '<nav class="crumbs" aria-label="%s"><a href="%s">%s</a> › <a href="%s">%s</a> › %s</nav>' % (u['crumbs_label'], url('home', lang), u['home'], url('articles', lang), u['articles'], u[m['pill']])
    aside = '<aside class="art-side" aria-label="%s"><nav class="toc side-toc" aria-label="%s"><b>%s</b>%s</nav><a class="side-cta" href="%s#radios"><b>%s</b><span>%s</span></a></aside>' % (
        u['toc'], u['toc'], u['toc'], toc_html, url('home', lang), u['side_cta_b'], fmt(u['side_cta_s'], n=str(N_ST)))
    main = ('<main id="main">\n\n<div class="progress" id="progress" aria-hidden="true"></div>\n<div class="wrap art-layout">\n<article class="art-main">\n' + crumb_html
            + '<span class="pill">%s</span>\n<h1>%s</h1>\n' % (u[m['pill']], esc(m['title'])) + byline + hero_img
            + '<nav class="toc toc-inline" aria-label="%s"><b>%s</b>%s</nav>\n' % (u['toc'], u['toc'], toc_html)
            + ad('article_top', lang) + '<div class="prose">' + body + '</div>\n' + ad('article_bottom', lang) + share + cta + author + related + '</article>\n' + aside + '\n</div>\n</main>\n')
    page = head(lang, m['mt'], m['desc'], path, image, 'article', alts, ld) + body_open(lang=lang) + header(lang, alts, 'articles') + main + footer(lang) + tail(lang)
    wr(os.path.join(OUT, path.lstrip('/') + '.html'), page)
    return path

# ------------------------------------------------------------------ simple static pages (FR / EN)
def render_static(lang, key):
    u = UI[lang]
    title, desc, body = LEGAL[key][lang]
    body = resolve(body, lang)
    path = url(key, lang)
    alts = alts_for(key)
    body_html = '<div class="prose">' + body + '</div>'
    main = ('<main id="main">\n\n<div class="wrap page">\n<nav class="crumbs" aria-label="%s"><a href="%s">%s</a> › %s</nav>\n<h1>%s</h1>\n%s\n</div>\n</main>\n') % (
        u['crumbs_label'], url('home', lang), u['home'], esc(title), esc(title), body_html)
    mt = title + ' | ' + u['brand_plain']
    ld = [{'@context': 'https://schema.org', '@type': 'WebPage', 'name': title, 'description': desc, 'inLanguage': lang, 'url': abs_url(path), 'isPartOf': {'@id': SITE + '/#website'}}]
    page = head(lang, mt, desc, path, 'og-home.jpg', 'website', alts, ld) + body_open(lang=lang) + header(lang, alts, key if key in ('about', 'contact') else '') + main + footer(lang) + tail(lang)
    wr(os.path.join(OUT, path.lstrip('/') + '.html'), page)

# ------------------------------------------------------------------ hubs
def render_hub(lang):
    u = UI[lang]
    path = url('articles', lang)
    alts = alts_for('articles')
    if lang == 'ar':
        n_total = 12 + len(GUIDES) - 1 + len(STATIONS)
        s = rd(os.path.join(OUT, 'articles.html'))
        s = re.sub(r'<p class="intro">.*?</p>', '<p class="intro">' + fmt(u['hub_intro'], n=str(n_total)) + '</p>', s, count=1, flags=re.S)
        new_guides = [k for k in GUIDES if k != 'listen-online']
        add = ('<section class="sec" aria-labelledby="gn1"><h2 class="sec-title" id="gn1">%s</h2><div class="agrid">%s</div></section>'
               '<section class="sec" aria-labelledby="gn2"><h2 class="sec-title" id="gn2">%s</h2><div class="agrid">%s</div></section>') % (
               u['hub_g_cities'], ''.join(card('ar', k) for k in new_guides), u['hub_g_stations'], ''.join(card('ar', k) for k in STATIONS))
        i = s.rfind('</section>') + len('</section>')
        s = s[:i] + add + s[i:]
        # head patches
        s = s.replace('<link rel="canonical" href="%s">' % abs_url('/articles'), '<link rel="canonical" href="%s">' % abs_url('/articles') + alt_links(alts))
        wr(os.path.join(OUT, 'articles.html'), s)
        return
    n_total = len(GUIDES) + len(STATIONS) + len(OLD)
    groups = [(u['hub_g_guides'], ['listen-online', 'smart-speaker', 'fm-frequencies', 'car', 'abroad', 'fix']),
              (u['hub_g_cities'], ['french-radio', 'casablanca', 'marrakech-tangier', 'regional', 'medi1-channels', 'chaabi']),
              (u['hub_g_more'], ['best', 'news', 'history', 'music', 'sports', 'ramadan', 'amazigh']),
              (u['hub_g_stations'], list(STATIONS.keys()))]
    secs = ''.join('<section class="sec" aria-labelledby="g%d"><h2 class="sec-title" id="g%d">%s</h2><div class="agrid">%s</div></section>' % (
        i, i, t, ''.join(card(lang, k) for k in ks)) for i, (t, ks) in enumerate(groups))
    main = ('<main id="main">\n\n<div class="wrap page-wide">\n<nav class="crumbs" aria-label="%s"><a href="%s">%s</a> › %s</nav>\n<h1>%s</h1>\n<p class="intro">%s</p>\n%s\n</div>\n</main>\n') % (
        u['crumbs_label'], url('home', lang), u['home'], u['articles'], u['hub_h1'], fmt(u['hub_intro'], n=str(n_total)), secs)
    ld = [{'@context': 'https://schema.org', '@type': 'CollectionPage', 'name': u['hub_h1'], 'inLanguage': lang, 'url': abs_url(path), 'isPartOf': {'@id': SITE + '/#website'}}]
    page = head(lang, u['hub_h1'] + ' | ' + u['brand_plain'], fmt(u['hub_intro'], n=str(n_total)), path, 'og-home.jpg', 'website', alts, ld) + body_open(lang=lang) + header(lang, alts, 'articles') + main + footer(lang) + tail(lang)
    wr(os.path.join(OUT, path.lstrip('/') + '.html'), page)

# ------------------------------------------------------------------ home pages
def station_card(lang, sid):
    u = UI[lang]; s = STN[sid]
    nm = esc(s['name'])
    city = CITY.get(s['city'], {}).get(lang, s['city'])
    cat = CAT.get(s['cat'], {}).get(lang, s['cat'])
    langs = ' / '.join(lang_words(lang, sid))
    search = ' '.join([s['name'], s['cat'], cat, s['city'], city, s['lang'], langs]).lower()
    logo = ('<img src="%s" alt="%s" width="62" height="62" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.remove()">' % (esc(s['logo']), esc(fmt(u['logo_alt'], name=s['name'])))) if s['logo'] else ''
    title = '<a href="%s">%s</a>' % (url(ST_KEY[sid], lang), nm) if sid in ST_KEY else nm
    return ('<article class="station" data-id="%d" data-cat="%s" data-lang="%s" data-search="%s"><div class="tile-top"><div class="logo"><span>%s</span>%s</div><span class="eq" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'
            '<button class="fav" type="button" data-fav="%d" aria-pressed="false" aria-label="%s"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/></svg></button></div>'
            '<h3>%s</h3><p class="meta">%s • %s</p><p class="np" hidden></p><div class="tile-foot"><button class="play" type="button" data-play="%d" aria-label="%s"><span class="disc"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></span><span class="play-label">%s</span></button><span class="tag">%s</span></div></article>') % (
            sid, esc(s['cat']), esc(s['lang']), esc(search), esc(s['init']), logo, sid, esc(fmt(u['fav_save'], name=s['name'])), title, esc(city), esc(langs), sid, esc(fmt(u['listen_to'], name=s['name'])), u['listen'], esc(cat))

def render_home(lang):
    u = UI[lang]; path = url('home', lang); alts = alts_for('home')
    best_t = {'ar': 'best'}.get(lang, 'best')
    dir_intro = fmt(u['dir_intro'], n=str(N_ST), best=url('best', lang))
    chips = [('all', u['all'])] + [('cat:' + k, CAT[k][lang]) for k in ['موسيقى', 'أخبار', 'وطنية', 'جهوية', 'دينية', 'رياضة', 'مجتمع']] + [('lang:فرنسية', u['f_fr']), ('lang:أمازيغية', u['f_am']), ('fav', u['fav_chip'])]
    chip_html = ''.join('<button class="chip" type="button" data-filter="%s" aria-pressed="%s">%s</button>' % (f, 'true' if f == 'all' else 'false', l) for f, l in chips)
    grid = ''.join(station_card(lang, sid) for sid in STN)
    tl = u['topic_labels']
    tmap = [(k, url(k, lang)) for k in ['news', 'sports', 'music', 'ramadan', 'amazigh', 'abroad', 'car', 'fix']]
    topics = ''.join('<a class="topic" href="%s"><span>%s</span></a>' % (h, tl[k]) for k, h in tmap)
    st_pages = ''.join('<a class="topic" href="%s"><span>%s</span></a>' % (url(k, lang), esc(sname(lang, v['id']))) for k, v in STATIONS.items())
    recent = ['best', 'fm-frequencies', 'medi1-channels', 'listen-online', 'smart-speaker', 'casablanca']
    cards_html = ''.join(card(lang, k) for k in recent)
    n_total = len(GUIDES) + len(STATIONS) + len(OLD)
    faq_html = ''.join('<details class="faq"><summary>%s</summary><p>%s</p></details>' % (q, a) for q, a in u['faq'])
    faq_ld_ = {'@context': 'https://schema.org', '@type': 'FAQPage', 'mainEntity': [{'@type': 'Question', 'name': q, 'acceptedAnswer': {'@type': 'Answer', 'text': a}} for q, a in u['faq']]}
    title = {'ar': 'راديو المغرب (Radio Maroc) | استمع إلى الإذاعات المغربية مباشرة', 'fr': 'Radio Maroc en direct : écouter les radios marocaines en ligne', 'en': 'Radio Maroc Live: Listen to Moroccan Radio Stations Online'}[lang]
    desc = {'ar': 'راديو المغرب FM: استمع مباشرة إلى ميدي 1 وهيت راديو وراديو مارس وشذى FM وأكثر من 40 محطة مغربية مجاناً من الهاتف، مع أدلة ومقالات تساعدك على الاختيار.',
            'fr': 'Radio Maroc en direct : écoutez la radio marocaine en ligne gratuitement. Medi 1, Hit Radio, Radio Mars, Chada FM et plus de 40 stations FM en direct sur mobile.',
            'en': 'Radio Maroc live: listen to Moroccan radio online for free. Medi 1, Hit Radio, Radio Mars, Chada FM and 40+ FM stations streaming live on your phone.'}[lang]
    org = {'@type': 'Organization', '@id': SITE + '/#org', 'name': 'Radio Maroc', 'url': SITE + '/', 'logo': {'@type': 'ImageObject', 'url': SITE + '/app-icon.png', 'width': 512, 'height': 512},
           'contactPoint': {'@type': 'ContactPoint', 'contactType': 'customer support', 'email': EMAIL, 'availableLanguage': ['Arabic', 'French', 'English']}, 'sameAs': [PLAY_URL]}
    site = {'@type': 'WebSite', '@id': SITE + '/#website', 'url': SITE + '/', 'name': u['brand_plain'], 'description': desc, 'inLanguage': ['ar', 'fr', 'en'], 'publisher': {'@id': SITE + '/#org'}}
    il = {'@type': 'ItemList', 'name': u['guides_title'], 'itemListElement': [{'@type': 'ListItem', 'position': i + 1, 'url': abs_url(url(k, lang)), 'name': META[lang][k]['title']} for i, k in enumerate(recent)]}
    ld = [{'@context': 'https://schema.org', '@graph': [site, org, il]}, faq_ld_]
    promo = ('<div class="promo" id="promo" role="complementary"><span class="app-icon p-ico" style="width:40px;height:40px"><img src="/app-icon.png" alt="%s" width="40" height="40" decoding="async"></span>'
             '<div class="p-txt"><b>%s</b><small>%s</small></div><a class="p-btn" href="%s" target="_blank" rel="noopener">%s</a><button class="p-close" id="promoClose" type="button" aria-label="X">✕</button></div>\n') % (
             esc(u['app_alt']), u['promo_b'], u['promo_s'], PLAY_URL, u['promo_btn'])
    hero = ('<section class="wrap hero" aria-labelledby="h1">\n<div class="hero-copy"><span class="kicker"><span class="dot"></span> %s</span>\n<h1 id="h1">%s</h1>\n<p>%s</p>\n'
            '<div class="hero-actions"><button class="btn btn-ivory" id="heroPlay" type="button">%s</button><a class="btn btn-ghost" href="#radios">%s</a></div></div>\n'
            '<div class="hero-art"><img src="/art-stations.svg" alt="%s" width="1200" height="630" fetchpriority="high" decoding="async"></div>\n</section>\n') % (
            u['h_kicker'], u['h_h1'], u['h_p'], u['listen_now'], u['h_browse'], esc(u['hero_alt']))
    stats = '<div class="wrap"><ul class="stats" aria-label="%s">\n<li><b>%d</b><span>%s</span></li><li><b>%d</b><span>%s</span></li><li><b>0</b><span>%s</span></li><li><b>100%%</b><span>%s</span></li></ul></div>\n' % (
        u['stats_aria'], N_ST, u['s1'], n_total, u['s2'], u['s3'], u['s4'])
    dirsec = ('<section id="radios" class="wrap sec" aria-labelledby="dir-h">\n<div class="head"><div><div class="eyebrow">STATION DIRECTORY</div><h2 class="sec-title" id="dir-h">%s <span class="count" id="countTxt">%d</span></h2></div>\n'
              '<label class="search"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6b6966" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg><input id="mainSearch" type="search" placeholder="%s" aria-label="%s"></label></div>\n'
              '<p class="intro">%s</p>\n<div class="recent" id="recentBox" hidden><span class="recent-h">%s</span><div class="recent-list" id="recentList"></div></div>\n<div class="filters" role="group" aria-label="%s">%s</div>\n<div class="grid" id="stationGrid">%s</div>\n<div class="empty" id="emptyBox" hidden>%s</div>\n</section>\n') % (
              u['dir_title'], N_ST, esc(u['search_ph']), esc(u['search_aria']), dir_intro, esc(EXTRA[lang]['recent']), esc(u['filters_aria']), chip_html, grid, fmt(u['empty'], contact=url('contact', lang)))
    topics_sec = '<section class="wrap sec" aria-labelledby="topics-h">\n<div class="head"><div><div class="eyebrow">EXPLORE BY NEED</div><h2 class="sec-title" id="topics-h">%s</h2></div></div>\n<div class="topics">%s</div>\n</section>\n' % (u['topics_title'], topics)
    pages_sec = '<section class="wrap sec" aria-labelledby="pg-h">\n<div class="head"><div><div class="eyebrow">STATION PAGES</div><h2 class="sec-title" id="pg-h">%s</h2></div></div>\n<p class="intro">%s</p>\n<div class="topics">%s</div>\n</section>\n' % (u['pages_title'], u['pages_intro'], st_pages)
    art_sec = ('<section class="wrap sec" aria-labelledby="art-h">\n<div class="head"><div><div class="eyebrow">LISTENING GUIDES</div><h2 class="sec-title" id="art-h">%s</h2></div><a href="%s" style="font-weight:700">%s</a></div>\n<p class="intro">%s</p>\n<div class="agrid">%s</div>\n</section>\n') % (
        u['guides_title'], url('articles', lang), fmt(u['all_articles'], n=str(n_total)), u['guides_intro'], cards_html)
    appcard = ('<div class="wrap"><div class="app-card"><span class="app-icon" style="width:64px;height:64px"><img src="/app-icon.png" alt="%s" width="64" height="64" decoding="async" loading="lazy"></span><div><b>%s</b><small>%s</small></div>'
               '<a class="btn" href="%s" target="_blank" rel="noopener">%s</a></div></div>\n') % (esc(u['app_alt']), u['app_b'], u['app_s'], PLAY_URL, u['app_btn'])
    about_sec = '<section class="wrap box" aria-labelledby="about-h">\n<h2 id="about-h">%s</h2>\n<p>%s</p>\n<h3>%s</h3>\n%s\n</section>\n' % (u['about_h'], fmt(u['about_p'], about=url('about', lang)), u['faq_h'], faq_html)
    main = '<main id="main">\n\n' + hero + stats + dirsec + '\n' + ad('home_mid', lang) + '\n\n' + topics_sec + pages_sec + art_sec + '\n' + appcard + '\n' + about_sec + '\n</main>\n'
    page = head(lang, title, desc, path, 'og-home.jpg', 'website', alts, ld, home=True, early=(REDIRECT_JS if lang == 'ar' else '')) + body_open(True, lang) + header(lang, alts, 'home') + main + footer(lang) + tail(lang, home=True)
    wr(os.path.join(OUT, 'index.html' if lang == 'ar' else path.lstrip('/') + 'index.html'), page)

# ------------------------------------------------------------------ run: generated pages
for lang in LANGS:
    for key in list(GUIDES) + list(STATIONS) + (list(OLD) if lang != 'ar' else []):
        render_page(lang, key)
for lang in ('fr', 'en'):
    for key in ('about', 'contact', 'privacy', 'terms', 'disclaimer', 'cookies'):
        render_static(lang, key)
for lang in LANGS:
    render_hub(lang)
    render_home(lang)

# ------------------------------------------------------------------ patch existing Arabic pages
def ar_common(s):
    s = re.sub(r'(<meta name="viewport"[^>]*>)', lambda m: m.group(1) + '\n' + ADSENSE_META.strip(), s, count=1)
    if ADSENSE_SCRIPT not in s: s = s.replace('</head>', ADSENSE_SCRIPT + '</head>', 1)
    if 'id="crit-banner"' not in s: s = s.replace('</head>', CRIT_CSS + '</head>', 1)
    if 'class="appbanner"' not in s: s = re.sub(r'(<body[^>]*>)', lambda m: m.group(1) + '\n' + app_banner('ar'), s, count=1)
    if 'id="playerBar"' not in s and '<div class="cookie"' in s:
        s = s.replace('<div class="cookie"', player_assets('ar') + play_modal('ar') + '<div class="cookie"', 1)
    if 'window.RM_I18N' not in s: s = re.sub(r'(<script src="/app\.js)', lambda m: i18n_script('ar') + m.group(1), s, count=1)
    s = s.replace('<a href="/cookies">الكوكيز</a>', '<a href="/cookies">الكوكيز</a><a href="/privacy" data-privacy-opts>%s</a>' % PRIV_OPTS['ar'], 1)
    return s

SKIP = {'index.html', 'articles.html', '404.html'} | {v['slug']['ar'] + '.html' for v in GUIDES.values()} | {v['slug']['ar'] + '.html' for v in STATIONS.values()}
st_row = '<div class="foot-links" style="margin-top:14px"><b>%s:</b>%s</div>\n' % (UI['ar']['foot_stations'], ''.join('<a href="%s">%s</a>' % (url(k, 'ar'), esc(sname('ar', v['id']))) for k, v in STATIONS.items()))
for fn in sorted(os.listdir(OUT)):
    if not fn.endswith('.html') or fn in SKIP: continue
    p = os.path.join(OUT, fn); s = rd(p); slug = fn[:-5]
    key = next((k for k, v in STATIC.items() if v['ar'] == slug), None) or next((k for k, v in OLD.items() if v['slug']['ar'] == slug), None)
    alts = alts_for(key) if key else None
    s = s.replace('/style.css"', '/style.css%s"' % CSSV).replace('/app.js"', '/app.js%s"' % CSSV)
    if alts:
        canon = '<link rel="canonical" href="%s">' % abs_url('/' + slug)
        s = s.replace(canon, canon + alt_links(alts), 1)
    s = s.replace('<button class="menu-btn"', lang_switcher('ar', alts or {}) + '<button class="menu-btn"', 1)
    if '<div class="copy">' in s and st_row not in s:
        s = s.replace('<div class="copy">', st_row + '<div class="copy">', 1)
    s = s.replace('contact@radiomaroc.example', EMAIL).replace('مد راديو', 'ميد راديو')
    if slug == 'privacy':
        s = s.replace('<p>للتفاصيل الكاملة عن الأنواع التي نستعملها وكيفية إدارتها، راجع', '<p>بالنسبة للزوار في المنطقة الاقتصادية الأوروبية والمملكة المتحدة وسويسرا، نعتمد رسالة موافقة معتمدة من Google (أداة إدارة موافقة معتمدة) تتيح لك قبول ملفات الإعلانات أو رفضها أو تخصيصها، ويمكنك تغيير اختيارك في أي وقت عبر رابط «إعدادات الخصوصية» في أسفل كل صفحة. وتعمل Google بوصفها طرفاً ثالثاً (Third-party vendor) تستعمل ملفات تعريف الارتباط لعرض الإعلانات بناءً على زياراتك السابقة لهذا الموقع أو لمواقع أخرى.</p>\n<p>للتفاصيل الكاملة عن الأنواع التي نستعملها وكيفية إدارتها، راجع', 1)
    wr(p, ar_common(s))
# 404 page: cache-busting + language switcher
p = os.path.join(OUT, '404.html'); s = rd(p)
s = s.replace('/style.css"', '/style.css%s"' % CSSV).replace('/app.js"', '/app.js%s"' % CSSV)
s = s.replace('<button class="menu-btn"', lang_switcher('ar', {}) + '<button class="menu-btn"', 1)
s = ar_common(s)
MAIN404 = ('<main id="main">\n\n<div class="wrap page" style="text-align:center;padding-block:70px">\n'
  '<div data-l="ar" lang="ar" dir="rtl"><h1>الصفحة غير موجودة</h1><p>ربما تغيّر الرابط أو حُذفت الصفحة. يمكنك العودة إلى <a href="/">دليل المحطات</a> أو تصفح <a href="/articles">المقالات</a>.</p></div>\n'
  '<div data-l="fr" lang="fr" dir="ltr" hidden><h1>Page introuvable</h1><p>Le lien a peut-être changé ou la page a été supprimée. Retournez au <a href="/fr/">guide des stations</a> ou parcourez les <a href="/fr/articles">articles</a>.</p></div>\n'
  '<div data-l="en" lang="en" dir="ltr" hidden><h1>Page not found</h1><p>The link may have changed or the page may have been removed. Go back to the <a href="/en/">station directory</a> or browse the <a href="/en/articles">articles</a>.</p></div>\n'
  '<script>(function(){var p=location.pathname,l=p.indexOf("/fr/")===0?"fr":p.indexOf("/en/")===0?"en":null;if(!l){var L=navigator.languages||[navigator.language||"en"];for(var i=0;i<L.length;i++){var c=String(L[i]).toLowerCase().split("-")[0];if(c==="ar"||c==="fr"||c==="en"){l=c;break}}if(!l)l="en"}'
  '[].forEach.call(document.querySelectorAll("[data-l]"),function(d){d.hidden=d.getAttribute("data-l")!==l});document.documentElement.lang=l;document.documentElement.dir=l==="ar"?"rtl":"ltr"})();</script>\n'
  '</div>\n</main>\n')
s = re.sub(r'<main id="main">.*?</main>\n', lambda m: MAIN404, s, count=1, flags=re.S)
wr(p, s)
# patch hub head (cache bust)
p = os.path.join(OUT, 'articles.html'); s = rd(p)
s = s.replace('/style.css"', '/style.css%s"' % CSSV).replace('/app.js"', '/app.js%s"' % CSSV)
s = s.replace('<button class="menu-btn"', lang_switcher('ar', alts_for('articles')) + '<button class="menu-btn"', 1)
if st_row not in s: s = s.replace('<div class="copy">', st_row + '<div class="copy">', 1)
wr(p, ar_common(s))

# ------------------------------------------------------------------ app.js (i18n + player on any page)
wr(os.path.join(OUT, 'app.js'), rd(os.path.join(HERE, 'app_src.js')))

# ------------------------------------------------------------------ CSS additions
NEWCSS = r'''
/* ===== app banner, Google Play popup, now playing (2026-11-20) ===== */
.appbanner{background:linear-gradient(90deg,#272225,#3d2c31);color:#fff6ed;position:relative;z-index:45;border-bottom:1px solid #00000040}
html.no-appbanner .appbanner{display:none}
.appbanner-in{display:flex;align-items:center;gap:10px;min-height:62px;padding-block:8px}
.appbanner .x{background:none;border:0;color:#cdb9ad;font-size:24px;line-height:1;cursor:pointer;padding:6px 8px;border-radius:8px}
.appbanner .x:hover{background:#ffffff14;color:#fff}
.appbanner .open{display:flex;align-items:center;gap:12px;flex:1;min-width:0;background:none;border:0;color:inherit;cursor:pointer;text-align:start;padding:0;font:inherit}
.appbanner .ico{width:46px;height:46px;border-radius:12px;overflow:hidden;flex-shrink:0;box-shadow:0 3px 10px #0006;background:#fff;display:block}
.appbanner .ico img{width:100%;height:100%;display:block}
.appbanner .txt{min-width:0;line-height:1.35}
.appbanner .txt b{display:block;font-size:14.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.appbanner .txt small{display:block;font-size:12px;color:#e2cfc2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.appbanner .get{background:#01875f;color:#fff;font-weight:800;border:0;border-radius:22px;padding:9px 20px;cursor:pointer;font-size:13.5px;flex-shrink:0;box-shadow:0 2px 8px #01875f66}
.appbanner .get:hover{background:#017652}
html.pm-lock,html.pm-lock body{overflow:hidden}
.pm{position:fixed;inset:0;z-index:500;display:none;align-items:center;justify-content:center;padding:16px;background:#000000a6;backdrop-filter:blur(2px)}
.pm.open{display:flex;animation:pmfade .18s ease-out}
@keyframes pmfade{from{opacity:0}to{opacity:1}}
.pm-card{background:#fff;color:#202124;width:min(440px,100%);max-height:min(90vh,760px);overflow:auto;border-radius:22px;box-shadow:0 28px 80px #0007;position:relative;font-family:Roboto,'IBM Plex Sans Arabic','Segoe UI',Arial,sans-serif;animation:pmup .22s ease-out}
@keyframes pmup{from{transform:translateY(18px)}to{transform:none}}
.pm-x{position:absolute;top:10px;inset-inline-end:10px;width:38px;height:38px;border-radius:50%;border:0;background:#f1f3f4;color:#202124;font-size:24px;line-height:1;cursor:pointer;z-index:2}
.pm-x:hover{background:#e3e5e8}
.pm-top{display:flex;align-items:center;gap:8px;padding:18px 22px 0;font-size:15px;font-weight:500;color:#5f6368}
.pm-head{display:flex;gap:16px;align-items:center;padding:16px 22px 8px}
.pm-ico{width:84px;height:84px;border-radius:22px;flex-shrink:0;box-shadow:0 2px 10px #0003;background:#fff}
.pm-title{font-size:22px;font-weight:500;line-height:1.25;margin:0;color:#202124}
.pm-dev{color:#01875f;font-weight:500;font-size:14px;margin-top:2px}
.pm-sub{color:#5f6368;font-size:13px;margin-top:2px}
.pm-meta{display:flex;justify-content:space-around;gap:6px;border-block:1px solid #e8eaed;margin:10px 22px 0;padding:12px 0;text-align:center}
.pm-meta b{font-size:13.5px;font-weight:500;color:#202124}
.pm-install{display:block;margin:16px 22px 10px;background:#01875f;color:#fff;text-align:center;border-radius:24px;padding:13px;font-weight:500;font-size:15px;text-decoration:none}
.pm-install:hover{background:#017652;color:#fff}
.pm-shots{display:flex;gap:10px;overflow-x:auto;padding:8px 22px 12px}
.pm-shots img{height:260px;width:auto;border-radius:12px;flex-shrink:0;border:1px solid #e8eaed}
.pm-about{padding:6px 22px 22px}
.pm-about h3{font-size:16px;font-weight:500;margin:10px 0 6px}
.pm-about p{margin:0 0 8px;color:#3c4043;font-size:14px;line-height:1.7}
.pm-about ul{margin:0;padding-inline-start:20px;color:#3c4043;font-size:14px;line-height:1.9}
@media(max-width:560px){.pm{align-items:flex-end;padding:0}.pm-card{width:100%;max-height:92vh;border-radius:22px 22px 0 0}.appbanner .get{padding:8px 16px}}
.player{background:linear-gradient(180deg,#2e2529,#221a1e)}
.player-in{gap:14px}
.player .logo{width:54px;height:54px;border-radius:12px;overflow:hidden;position:relative;display:grid;place-items:center}
.player .logo img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#fff}
.ptrack{font-size:13px;color:#f3dccc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:19px}
.ptrack.is-track::before{content:"♪ ";color:#f39c7d}
.eq{display:none;align-items:flex-end;gap:2px;height:14px}
.eq i{display:block;width:3px;height:4px;background:#f39c7d;border-radius:2px;animation:eqb 1s ease-in-out infinite}
.eq i:nth-child(2){animation-delay:.18s}.eq i:nth-child(3){animation-delay:.36s}.eq i:nth-child(4){animation-delay:.54s}
@keyframes eqb{0%,100%{height:3px}50%{height:14px}}
.player.playing .eq,.station.playing .eq{display:inline-flex}
.station .eq{margin-inline-start:auto;margin-inline-end:8px;margin-top:6px}
.station .eq i{background:var(--red)}
.vol{width:96px;accent-color:#f39c7d;cursor:pointer}
@media(max-width:700px){.vol{display:none}}
.np{margin:-6px 0 10px;font-size:12.5px;color:var(--red-d);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.np[hidden]{display:none}
.station.playing{background:linear-gradient(180deg,#fff7f3,var(--card))}
.station .tag{max-width:46%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.station .play{flex-shrink:0}
.recent{margin:2px 0 4px;padding:12px 0 2px}
.recent[hidden]{display:none}
.recent-h{display:block;font:700 12px var(--mono);letter-spacing:.06em;color:var(--dim);margin-bottom:8px}
.recent-list{display:flex;gap:8px;overflow-x:auto;padding-bottom:6px;scrollbar-width:thin}
.rchip{display:inline-flex;align-items:center;gap:9px;background:var(--card);border:1px solid var(--line);border-radius:30px;padding:5px 14px 5px 5px;cursor:pointer;white-space:nowrap;font:inherit;font-size:13.5px;font-weight:600;color:var(--ink);transition:.18s}
html[dir=rtl] .rchip{padding:5px 5px 5px 14px}
.rchip:hover{border-color:var(--red);color:var(--red)}
.rchip .rl{width:30px;height:30px;border-radius:50%;background:#f0e7df;color:#8a4a3f;display:grid;place-items:center;font-size:10px;font-weight:800;overflow:hidden}
.rchip .rl img{width:100%;height:100%;object-fit:cover;background:#fff}
@media(max-width:560px){.top-inner{min-height:60px;gap:8px}.brand-name{font-size:19px}.brand-sub{display:none}.menu-btn{padding:7px 10px;font-size:13px}.hero-copy h1{font-size:2rem}}
:focus-visible{outline:2px solid var(--red);outline-offset:2px}
.adslot{margin:26px 0;text-align:center;min-height:100px;clear:both}
.adlabel{display:block;font:600 11px var(--mono);letter-spacing:.08em;color:var(--dim);margin-bottom:6px;text-transform:uppercase}
'''
css = rd(os.path.join(SRC, 'style.css'))
if '/* ===== i18n + station pages' not in css:
    css += '''
/* ===== i18n + station pages (2026-11-20) ===== */
.langsw{display:inline-flex;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#fff}
.langsw a{padding:6px 10px;font:700 12px var(--mono);color:#4d4a47;text-decoration:none;letter-spacing:.04em}
.langsw a:hover{background:#f6efe9;color:var(--red)}
.langsw a[aria-current="true"]{background:var(--red);color:#fff}
html[dir=ltr] .eyebrow{justify-content:flex-start}
html[dir=ltr] body{font-family:'IBM Plex Sans Arabic','Segoe UI',system-ui,Arial,sans-serif}
.station h3 a{color:inherit;text-decoration:none}.station h3 a:hover{color:var(--red)}
.stn-hero{display:flex;gap:18px;align-items:center;flex-wrap:wrap;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px;margin:0 0 20px}
.stn-logo{width:78px;height:78px;border-radius:18px;background:#481d26;color:#fff;display:grid;place-items:center;font-weight:800;overflow:hidden;flex-shrink:0;position:relative}
.stn-logo img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#fff}
.stn-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 20px;margin:0;flex:1;min-width:220px}
.stn-facts dt{font-size:12px;color:var(--dim)}.stn-facts dd{margin:0;font-weight:700}
.stn-list{list-style:none;margin:0 0 1rem;padding:0;display:grid;gap:8px}
.stn-list li{display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 14px}
.stn-list .sl-main{display:flex;flex-direction:column;min-width:0}.stn-list .sl-main b{line-height:1.5}
.stn-list .sl-main a{color:var(--ink);text-decoration:none}.stn-list .sl-main a:hover{color:var(--red)}
.sl-meta{font-size:13px;color:var(--dim)}
.langbar{display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;background:#481d26;color:#fff;padding:8px 14px;font-size:14px}.langbar a{color:#ffd9c8;font-weight:700}.langbar button{background:none;border:0;color:#fff;font-size:20px;line-height:1;cursor:pointer;padding:0 6px}
html.rm-loading body::before{content:"";position:fixed;top:0;inset-inline:0;height:3px;background:var(--red);z-index:300;animation:rmload 1s ease-in-out infinite}@keyframes rmload{0%{transform:scaleX(.1);transform-origin:left}100%{transform:scaleX(1);transform-origin:left}}
.btn-sm{min-height:36px;padding:4px 14px;font-size:13px;flex-shrink:0}
.freq{width:100%;border-collapse:collapse;margin:0 0 1rem;font-size:15px}
.freq th,.freq td{border:1px solid var(--line);padding:8px 10px;text-align:start}.freq th{background:#f4f2eb}
.note-box{background:#f4f2eb;border:1px solid var(--line);border-radius:12px;padding:14px 16px;font-size:15.5px;line-height:1.9;margin:0 0 1rem}
'''+NEWCSS+'''@media(max-width:860px){.langsw{order:2}}
@media(max-width:560px){.langsw a{padding:5px 7px;font-size:11px}.top-inner{gap:8px}.tools{gap:6px}.clock{display:none}}
'''
    wr(os.path.join(OUT, 'style.css'), css)

# ------------------------------------------------------------------ manifest, data, sitemap, feed
man = json.loads(rd(os.path.join(SRC, 'manifest.webmanifest')))
man.update({'id': '/', 'start_url': '/', 'scope': '/'})
for ic in man.get('icons', []): ic['src'] = ic['src'].replace('/Raddddddd/', '/')
wr(os.path.join(OUT, 'manifest.webmanifest'), json.dumps(man, ensure_ascii=False, indent=1))

wr(os.path.join(OUT, 'ads.txt'), 'google.com, pub-6369463662612526, DIRECT, f08c47fec0942fa0\n')
os.makedirs(os.path.join(OUT, 'data'), exist_ok=True)
for _n, _d in (('play.json', {'_help': 'Google Play popup details. Fill only what is true. screenshots: list of paths such as /play/shot-1.jpg (put the image files in the play/ folder), name/developer/rating/downloads/description are optional.', 'name': '', 'developer': '', 'rating': '', 'downloads': '', 'screenshots': [], 'description': ''}),
               ('nowplaying.json', {'_help': 'Optional now-playing endpoints. stations: {"<station id>": {"url": "https://.../status-json.xsl", "path": "icestats.source.title", "every": 20}}. The endpoint must allow CORS. HLS streams that carry ID3 titles need no setup.', 'stations': {}})):
    if not os.path.exists(os.path.join(OUT, 'data', _n)): wr(os.path.join(OUT, 'data', _n), json.dumps(_d, ensure_ascii=False, indent=1))
if not os.path.exists(os.path.join(OUT, 'data', 'adsense.json')):
    wr(os.path.join(OUT, 'data', 'adsense.json'), json.dumps({'_help': 'Optional manual AdSense units. Paste the ad-slot IDs from your AdSense account (Ads > By ad unit). Leave empty to rely on Auto ads. Keys: article_top, article_bottom, home_mid.', 'slots': {'article_top': '', 'article_bottom': '', 'home_mid': ''}}, ensure_ascii=False, indent=1))
wr(os.path.join(OUT, 'sw.js'), '''// Retired service worker: the old one imported a third-party push-ads script. This version removes itself.
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) {
  e.waitUntil((async function () {
    try { var ks = await caches.keys(); await Promise.all(ks.map(function (k) { return caches.delete(k); })); } catch (x) {}
    try { await self.registration.unregister(); } catch (x) {}
  })());
});
''')
os.makedirs(os.path.join(OUT, 'play'), exist_ok=True)
if not os.path.exists(os.path.join(OUT, 'play', 'README.txt')):
    wr(os.path.join(OUT, 'play', 'README.txt'), 'Put your Google Play screenshots here (shot-1.jpg, shot-2.jpg, ...), then list them in data/play.json under "screenshots" and rebuild.\n')
if os.path.exists(FREQ_PATH):
    shutil.copy(FREQ_PATH, os.path.join(OUT, 'data', 'frequencies.json'))
if not os.path.exists(os.path.join(OUT, 'data', 'frequencies.json')):
    wr(os.path.join(OUT, 'data', 'frequencies.json'), json.dumps({
        '_help': 'Add verified FM frequencies here, then run: python3 tools/build.py . ./out . Each entry: station = directory id, city = Arabic city name as in the directory, mhz = number as text, verified = YYYY-MM-DD, source = URL of the official source (not shown on the page). Leave entries empty until a number is verified.',
        'last_verified': '', 'entries': []}, ensure_ascii=False, indent=1))

def sm_entry(path, lastmod, prio, alts=None):
    x = '<url><loc>%s</loc><lastmod>%s</lastmod><priority>%s</priority>' % (abs_url(path), lastmod, prio)
    if alts:
        for l, p in alts.items(): x += '<xhtml:link rel="alternate" hreflang="%s" href="%s"/>' % (l, abs_url(p))
        x += '<xhtml:link rel="alternate" hreflang="x-default" href="%s"/>' % abs_url(alts['en'])
    return x + '</url>\n'
def lang_sitemap(l):
    x = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n'
    x += sm_entry(url('home', l), TODAY, '1.0', alts_for('home'))
    x += sm_entry(url('articles', l), TODAY, '0.9', alts_for('articles'))
    for key in list(GUIDES) + list(STATIONS) + list(OLD): x += sm_entry(url(key, l), TODAY, '0.8', alts_for(key))
    for key in ('about', 'contact'): x += sm_entry(url(key, l), TODAY, '0.5', alts_for(key))
    for key in ('privacy', 'terms', 'disclaimer', 'cookies'): x += sm_entry(url(key, l), TODAY, '0.3', alts_for(key))
    return x + '</urlset>\n'
for l in LANGS: wr(os.path.join(OUT, 'sitemap-%s.xml' % l), lang_sitemap(l))
sm = '<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(
    '<sitemap><loc>%s/sitemap-%s.xml</loc><lastmod>%s</lastmod></sitemap>\n' % (SITE, l, TODAY) for l in LANGS) + '</sitemapindex>\n'
wr(os.path.join(OUT, 'sitemap.xml'), sm)
wr(os.path.join(OUT, 'robots.txt'), 'User-agent: *\nAllow: /\n\nSitemap: %s/sitemap.xml\nSitemap: %s/sitemap-ar.xml\nSitemap: %s/sitemap-fr.xml\nSitemap: %s/sitemap-en.xml\n' % (SITE, SITE, SITE, SITE))

feed = rd(os.path.join(SRC, 'feed.xml'))
items = ''
for key in list(GUIDES) + list(STATIONS):
    if key == 'listen-online': continue
    m = META['ar'][key]
    items += '<item><title>%s</title><link>%s</link><guid>%s</guid><pubDate>Fri, 20 Nov 2026 08:00:00 +0100</pubDate><description>%s</description></item>' % (
        html.escape(m['title']), abs_url(url(key, 'ar')), abs_url(url(key, 'ar')), html.escape(m['desc']))
m = META['ar']['listen-online']
feed = re.sub(r'(<item><title>)[^<]*(</title><link>%s</link>)' % re.escape(abs_url('/listen-radio-online-morocco')), r'\g<1>%s\g<2>' % html.escape(m['title']).replace('\\', ''), feed)
feed = feed.replace('<language>ar</language>', '<language>ar</language>' + items, 1) if False else feed.replace('</channel>', items + '</channel>')
wr(os.path.join(OUT, 'feed.xml'), feed)

print('OK. pages written under', OUT)
